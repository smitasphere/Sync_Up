/**
 * Main Client Game Controller for Arcade Arena · Tech Verse 2026
 * Synchronizes client state with the authoritative server via Socket.IO.
 */

(function () {
  let gameState = null;
  let playerNum = null;
  let serverBaseUrl = window.location.origin;
  let lastAttemptResult = null;

  // Discover server network info for QR code generation
  fetch('/api/server-info')
    .then((r) => r.json())
    .then((info) => {
      if (info && info.baseUrl) {
        serverBaseUrl = info.baseUrl;
        // If we are currently in the lobby displaying QR code, refresh join link with LAN IP
        if (gameState && (gameState.phase === 'LOBBY' || gameState.status === 'LOBBY' || gameState.status === 'READY')) {
          redraw();
        }
      }
    })
    .catch((err) => {
      console.warn('Could not fetch server-info:', err);
    });

  function getJoinUrl(roomCode) {
    return `${serverBaseUrl}/#${roomCode}`;
  }

  function redraw() {
    ArcadeUI.renderHud(gameState, playerNum);
    ArcadeUI.renderStrip(gameState);
    ArcadeUI.renderScene(gameState, playerNum, lastAttemptResult);
    ArcadeUI.renderPanel(gameState, playerNum, {
      getJoinUrl,
      onCreateRoom: () => {
        ArcadeSocket.createRoom('Player 1', (res) => {
          if (res && res.success) {
            gameState = res.gameState;
            playerNum = res.playerNum;
            window.location.hash = res.roomCode;
            ArcadeUI.showToast(`Room ${res.roomCode} created!`);
            redraw();
          } else {
            const btn = document.getElementById('btnCreateRoom');
            if (btn) {
              btn.disabled = false;
              btn.textContent = '🎮 CREATE NEW GAME ROOM';
            }
            ArcadeUI.showToast(`Error: ${res ? res.message : 'Could not create room'}`);
          }
        });
      },
      onJoinRoom: (code) => {
        ArcadeSocket.joinRoom(code, 'Player 2', (res) => {
          const btn = document.getElementById('btnJoinRoom');
          if (btn) {
            btn.disabled = false;
            btn.textContent = 'JOIN ROOM';
          }
          if (res && !res.success) {
            ArcadeUI.showToast(`Error: ${res.message || 'Failed to join room'}`);
          }
        });
      },
      onStartGame: () => {
        const btn = document.getElementById('btnStartGame');
        if (btn) {
          btn.disabled = true;
          btn.textContent = 'STARTING...';
        }
        ArcadeSocket.startGame();
      },
      onSubmitWord: (word) => {
        ArcadeSocket.submitWord(word);
      },
      onRequestNextAttempt: () => {
        lastAttemptResult = null;
        ArcadeSocket.requestNextAttempt();
      },
      onRequestNextLevel: () => {
        lastAttemptResult = null;
        ArcadeSocket.requestNextLevel();
      },
      onSubmitDsa: (problemId, code) => {
        const btn = document.getElementById('btnSubmitDsa');
        if (btn) {
          btn.disabled = true;
          btn.textContent = '⏳ RUNNING TESTS...';
        }
        ArcadeSocket.submitDsaSolution(problemId, code, 'python');
      },
      onPlayAgain: () => {
        ArcadeSocket.clearSession();
        window.location.hash = '';
        gameState = null;
        playerNum = null;
        lastAttemptResult = null;
        redraw();
      }
    }, lastAttemptResult);
  }

  // Socket event listeners
  const socketHandlers = {
    onConnectionChange: (status) => {
      ArcadeUI.updateConnectionPill(status);
    },

    room_created: (data) => {
      gameState = data.gameState;
      playerNum = data.playerNum;
      window.location.hash = data.roomCode;
      ArcadeUI.showToast(`Room ${data.roomCode} created!`);
      redraw();
    },

    room_joined: (data) => {
      gameState = data.gameState;
      playerNum = data.playerNum;
      window.location.hash = data.roomCode;
      ArcadeUI.showToast(`Joined Room ${data.roomCode} as Player ${playerNum}!`);
      redraw();
    },

    player_joined: (data) => {
      gameState = data.gameState;
      ArcadeUI.showToast(`Player ${data.playerNum} has connected!`);
      redraw();
    },

    player_disconnected: (data) => {
      ArcadeUI.showToast(`Player ${data.playerNum} disconnected. Waiting for reconnect...`);
    },

    player_reconnected: (data) => {
      gameState = data.gameState;
      ArcadeUI.showToast(`Player ${data.playerNum} reconnected!`);
      redraw();
    },

    room_full: (data) => {
      const btn = document.getElementById('btnJoinRoom');
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'JOIN ROOM';
      }
      ArcadeUI.showToast(data.message || 'Room is already full!');
    },

    game_ready: (data) => {
      gameState = data.gameState;
      ArcadeUI.showToast('Both players connected! Ready to begin.');
      redraw();
    },

    game_started: (data) => {
      gameState = data.gameState;
      lastAttemptResult = null;
      ArcadeUI.showToast('Level 1: AI Lab starting!');
      redraw();
    },

    level_started: (data) => {
      gameState = data.gameState;
      lastAttemptResult = null;
      redraw();
    },

    answer_locked: (data) => {
      gameState = data.gameState;
      ArcadeUI.showToast(`Player ${data.playerNum} locked in their answer!`);
      redraw();
    },

    waiting_for_partner: (data) => {
      gameState = data.gameState;
      redraw();
    },

    attempt_result: (data) => {
      lastAttemptResult = data;
      gameState = data.gameState;
      if (data.isMatch) {
        ArcadeScenes.burst();
      }
      redraw();
    },

    level_cleared: (data) => {
      gameState = data.gameState;
      ArcadeScenes.burst();
      redraw();
    },

    dsa_challenge_started: (data) => {
      gameState = data.gameState;
      ArcadeUI.showToast('3 mismatches! DSA challenge unlocked.');
      redraw();
    },

    dsa_submission_result: (data) => {
      const btn = document.getElementById('btnSubmitDsa');
      if (btn) {
        btn.disabled = false;
        btn.textContent = '⚡ RUN & SUBMIT SOLUTION';
      }
      gameState = data.gameState;
      ArcadeUI.showDsaResult(data);
      if (data.success) {
        ArcadeScenes.burst();
        setTimeout(redraw, 1500);
      }
    },

    player_eliminated: (data) => {
      gameState = data.gameState;
      redraw();
    },

    game_completed: (data) => {
      gameState = data.gameState;
      ArcadeScenes.burst();
      redraw();
    },

    game_state: (data) => {
      gameState = data.gameState;
      redraw();
    },

    error_message: (data) => {
      const createBtn = document.getElementById('btnCreateRoom');
      if (createBtn) {
        createBtn.disabled = false;
        createBtn.textContent = '🎮 CREATE NEW GAME ROOM';
      }
      const joinBtn = document.getElementById('btnJoinRoom');
      if (joinBtn) {
        joinBtn.disabled = false;
        joinBtn.textContent = 'JOIN ROOM';
      }
      ArcadeUI.showToast(`Error: ${data.message || 'Operation failed'}`);
    }
  };

  // Listen for browser hash changes (e.g. clicking an invite link or pasting into active tab)
  window.addEventListener('hashchange', () => {
    const hash = window.location.hash.replace('#', '').trim().toUpperCase();
    if (hash && /^TV\d{4}$/.test(hash)) {
      if (!gameState || gameState.roomCode !== hash) {
        ArcadeSocket.joinRoom(hash, 'Player 2');
      }
    }
  });

  // Initialize socket connection
  ArcadeSocket.init(socketHandlers);

  // Initial draw
  const session = ArcadeSocket.getSession();
  if (session && session.playerNum) {
    playerNum = session.playerNum;
  }
  redraw();
})();
