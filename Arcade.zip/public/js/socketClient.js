/**
 * Socket.IO Client Wrapper for Arcade Arena · Tech Verse 2026
 * Manages connection lifecycle, session token persistence, and real-time events.
 */

window.ArcadeSocket = (function () {
  let socket = null;
  let session = {
    roomId: null,
    sessionToken: null,
    playerNum: null,
    playerName: null
  };

  // Restore session from sessionStorage if available
  try {
    const saved = sessionStorage.getItem('arcade_arena_session');
    if (saved) {
      session = JSON.parse(saved);
    }
  } catch (e) {}

  function saveSession(data) {
    session = { ...session, ...data };
    try {
      sessionStorage.setItem('arcade_arena_session', JSON.stringify(session));
    } catch (e) {}
  }

  function clearSession() {
    session = { roomId: null, sessionToken: null, playerNum: null, playerName: null };
    try {
      sessionStorage.removeItem('arcade_arena_session');
    } catch (e) {}
  }

  function getSession() {
    return session;
  }

  function isConnected() {
    return !!(socket && socket.connected);
  }

  function init(eventHandlers = {}) {
    socket = io({
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000,
      timeout: 10000
    });

    // Connection lifecycle
    socket.on('connect', () => {
      console.log('Socket connected:', socket.id);
      if (eventHandlers.onConnectionChange) {
        eventHandlers.onConnectionChange('online');
      }

      // Check if URL has a room hash or existing session to reconnect/join
      const hash = window.location.hash.replace('#', '').trim().toUpperCase();

      if (hash && /^TV\d{4}$/.test(hash)) {
        // If hash exists and differs from stored session, join the hash room!
        if (session.roomId !== hash) {
          clearSession();
          session.roomId = hash;
        }
        socket.emit('join_room', {
          roomId: hash,
          sessionToken: session.sessionToken,
          playerName: 'Player 2'
        });
      } else if (session.roomId && session.sessionToken) {
        // Attempt session reconnect to existing room
        socket.emit('join_room', {
          roomId: session.roomId,
          sessionToken: session.sessionToken
        });
      }
    });

    socket.on('disconnect', () => {
      console.warn('Socket disconnected');
      if (eventHandlers.onConnectionChange) {
        eventHandlers.onConnectionChange('offline');
      }
    });

    socket.on('connect_error', (err) => {
      console.warn('Socket connection error:', err.message);
      if (eventHandlers.onConnectionChange) {
        eventHandlers.onConnectionChange('offline');
      }
    });

    socket.io.on('reconnect_attempt', () => {
      if (eventHandlers.onConnectionChange) {
        eventHandlers.onConnectionChange('reconnecting');
      }
    });

    // Wire up game events
    const events = [
      'room_created',
      'room_joined',
      'player_joined',
      'player_disconnected',
      'player_reconnected',
      'room_full',
      'game_ready',
      'game_started',
      'level_started',
      'answer_locked',
      'waiting_for_partner',
      'attempt_result',
      'level_cleared',
      'dsa_challenge_started',
      'dsa_submission_result',
      'player_eliminated',
      'game_completed',
      'game_state',
      'error_message'
    ];

    events.forEach((eventName) => {
      socket.on(eventName, (data) => {
        // Update session token/details if received
        if (data && data.sessionToken) {
          saveSession({
            roomId: data.roomCode || data.roomId,
            sessionToken: data.sessionToken,
            playerNum: data.playerNum,
            playerName: data.playerName
          });
        }

        // If dead session error returned, clear invalid session
        if (eventName === 'error_message' && data && (data.error === 'ROOM_NOT_FOUND' || data.error === 'INVALID_SESSION')) {
          clearSession();
        }

        if (eventHandlers[eventName]) {
          eventHandlers[eventName](data);
        }
      });
    });

    return socket;
  }

  /**
   * Resilient Create Room:
   * 1. If socket is connected, emits create_room with ack callback.
   * 2. Also provides an automatic REST API fallback (POST /api/rooms) so
   *    room creation NEVER hangs or fails even during initial handshake.
   */
  function createRoom(playerName, callback) {
    let resolved = false;

    const done = (res) => {
      if (resolved) return;
      resolved = true;
      if (res && res.success) {
        saveSession({
          roomId: res.roomCode,
          sessionToken: res.sessionToken,
          playerNum: res.playerNum,
          playerName: res.playerName
        });
        // Make sure socket is attached to this room
        if (socket && socket.connected) {
          socket.emit('join_room', {
            roomId: res.roomCode,
            sessionToken: res.sessionToken,
            playerName: res.playerName
          });
        }
      }
      if (callback) callback(res);
    };

    // Attempt Socket.IO emit first
    if (socket && socket.connected) {
      socket.emit('create_room', { playerName: playerName || 'Player 1' }, (res) => {
        if (res && res.success) {
          done(res);
        }
      });
    }

    // Immediate REST API fallback after 800ms if socket hasn't acknowledged
    setTimeout(() => {
      if (resolved) return;
      fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ playerName: playerName || 'Player 1' })
      })
        .then((r) => r.json())
        .then((data) => {
          if (data && data.success) {
            done(data);
          } else {
            done({ success: false, error: (data && data.error) || 'CREATE_FAILED', message: (data && data.message) || 'Failed to create room.' });
          }
        })
        .catch((err) => {
          done({ success: false, error: 'NETWORK_ERROR', message: err.message });
        });
    }, socket && socket.connected ? 1000 : 50);
  }

  /**
   * Resilient Join Room:
   */
  function joinRoom(roomId, playerName, callback) {
    const code = (roomId || '').toUpperCase().trim();
    if (!code) {
      if (callback) callback({ success: false, message: 'Room code is required.' });
      return;
    }

    if (socket && socket.connected) {
      socket.emit('join_room', {
        roomId: code,
        playerName: playerName || 'Player 2',
        sessionToken: session.sessionToken
      }, (res) => {
        if (res && res.success) {
          saveSession({
            roomId: res.roomCode,
            sessionToken: res.sessionToken,
            playerNum: res.playerNum,
            playerName: res.playerName
          });
        }
        if (callback) callback(res);
      });
      return;
    }

    // If socket is connecting, check room status via REST API first
    fetch(`/api/rooms/${code}`)
      .then((r) => r.json())
      .then((info) => {
        if (info.error) {
          if (callback) callback({ success: false, error: info.error, message: info.message });
          return;
        }
        if (info.isFull) {
          if (callback) callback({ success: false, error: 'ROOM_FULL', message: 'Room is full (max 2 players).' });
          return;
        }
        // Save target room code so socket joins when connected
        session.roomId = code;
        if (socket) {
          socket.emit('join_room', { roomId: code, playerName: playerName || 'Player 2' });
        }
        if (callback) callback({ success: true, roomCode: code, message: 'Joining room...' });
      })
      .catch((err) => {
        if (callback) callback({ success: false, error: 'NETWORK_ERROR', message: err.message });
      });
  }

  function startGame() {
    if (!socket || !session.roomId) return;
    socket.emit('start_game', {
      roomId: session.roomId,
      sessionToken: session.sessionToken
    });
  }

  function submitWord(word) {
    if (!socket || !session.roomId) return;
    socket.emit('submit_word', {
      roomId: session.roomId,
      sessionToken: session.sessionToken,
      word
    });
  }

  function requestNextAttempt() {
    if (!socket || !session.roomId) return;
    socket.emit('request_next_attempt', {
      roomId: session.roomId,
      sessionToken: session.sessionToken
    });
  }

  function requestNextLevel() {
    if (!socket || !session.roomId) return;
    socket.emit('request_next_level', {
      roomId: session.roomId,
      sessionToken: session.sessionToken
    });
  }

  function submitDsaSolution(problemId, code, language = 'python') {
    if (!socket || !session.roomId) return;
    socket.emit('submit_dsa_solution', {
      roomId: session.roomId,
      sessionToken: session.sessionToken,
      problemId,
      code,
      language
    });
  }

  function requestGameState() {
    if (!socket || !session.roomId) return;
    socket.emit('request_game_state', {
      roomId: session.roomId,
      sessionToken: session.sessionToken
    });
  }

  return {
    init,
    saveSession,
    clearSession,
    getSession,
    isConnected,
    createRoom,
    joinRoom,
    startGame,
    submitWord,
    requestNextAttempt,
    requestNextLevel,
    submitDsaSolution,
    requestGameState
  };
})();
