/**
 * UI Renderer and View Controller for Arcade Arena · Tech Verse 2026
 * Preserves the retro arcade cabinet, pixel-art scenes, neon colors, and responsive layout.
 */

window.ArcadeUI = (function () {
  const $ = (id) => document.getElementById(id);

  function esc(s) {
    return String(s || '').replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  function showToast(msg) {
    const existing = document.querySelector('.toast-msg');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'toast-msg';
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
  }

  function updateConnectionPill(status) {
    const pill = $('connPill');
    if (!pill) return;
    pill.className = `conn-pill ${status}`;
    if (status === 'online') pill.innerHTML = '🟢 CONNECTED';
    else if (status === 'reconnecting') pill.innerHTML = '🟡 RECONNECTING...';
    else pill.innerHTML = '🔴 OFFLINE';
  }

  function renderHud(state, playerNum) {
    const hud = $('hudBar');
    if (!hud) return;

    if (!state || state.phase === 'LOBBY') {
      hud.innerHTML = `
        <div class="hud-item sun">MODE: 2-PLAYER LIVE</div>
        <div class="hud-item ${playerNum ? 'pink' : ''}">${playerNum ? `YOU: PLAYER ${playerNum}${playerNum === 1 ? ' (HOST)' : ''}` : 'WELCOME'}</div>
        <div class="hud-item">LEVELS: 9 TOTAL</div>
      `;
      return;
    }

    const failedClass = state.failedLevels > 0 ? (state.failedLevels >= 2 ? 'hud-item warn' : 'hud-item sun') : 'hud-item';

    hud.innerHTML = `
      <div class="hud-item sun">LEVEL ${state.currentLevel}/9</div>
      <div class="hud-item">ATTEMPT ${state.currentAttempt}/3</div>
      <div class="${failedClass}">FAILED LEVELS: ${state.failedLevels}/3</div>
      <div class="hud-item pink">YOU: PLAYER ${playerNum || 1}${playerNum === 1 ? ' (HOST)' : ''}</div>
    `;
  }

  function renderStrip(state) {
    const strip = $('strip');
    if (!strip) return;

    if (!state || state.phase === 'LOBBY') {
      strip.innerHTML = '<span class="on">LOBBY · WAITING FOR PLAYERS</span>';
      return;
    }

    const zones = window.ArcadeScenes.ZONES;
    strip.innerHTML = zones.map((z, i) => {
      const lvl = i + 1;
      let cls = '';
      if (lvl === state.currentLevel && state.phase !== 'GAME_COMPLETED') cls = 'on';
      else if (lvl < state.currentLevel || (state.phase === 'GAME_COMPLETED' && lvl <= state.currentLevel)) cls = 'done';
      return `<span class="${cls}">LVL ${lvl} · ${z.name}</span>`;
    }).join('');
  }

  function renderScene(state, playerNum, lastAttemptResult) {
    const sceneEl = $('scene');
    if (!sceneEl) return;

    const zones = window.ArcadeScenes.ZONES;
    const currentZone = (state && state.zone) || zones[0];

    let t1 = '?';
    let t2 = '?';
    let hit = false;
    let isReveal = false;

    if (state) {
      if (state.phase === 'GUESSING') {
        if (state.submissionsLocked && state.submissionsLocked[1]) t1 = 'OK';
        if (state.submissionsLocked && state.submissionsLocked[2]) t2 = 'OK';
      } else if (state.phase === 'ATTEMPT_RESULT' || state.phase === 'LEVEL_CLEARED' || state.phase === 'GAME_COMPLETED') {
        isReveal = true;
        if (lastAttemptResult) {
          t1 = lastAttemptResult.p1Word || '';
          t2 = lastAttemptResult.p2Word || '';
          hit = !!lastAttemptResult.isMatch;
        } else if (state.currentLevelAttempts && state.currentLevelAttempts.length) {
          const last = state.currentLevelAttempts[state.currentLevelAttempts.length - 1];
          t1 = last.p1Word || '';
          t2 = last.p2Word || '';
          hit = !!last.isMatch;
        }
      }
    }

    sceneEl.innerHTML = window.ArcadeScenes.renderScene({
      zone: currentZone,
      text1: t1,
      text2: t2,
      label1: state && state.players && state.players[1] ? state.players[1].name.toUpperCase() : 'PLAYER 1',
      label2: state && state.players && state.players[2] ? state.players[2].name.toUpperCase() : 'PLAYER 2',
      hit,
      isReveal
    });
  }

  function renderHistory(attempts) {
    if (!attempts || !attempts.length) return '';
    return `
      <div class="hist">
        ${attempts.map((a) => `
          <span>Attempt ${a.attemptNum}: "${esc(a.p1Word)}" vs "${esc(a.p2Word)}" ${a.isMatch ? '⭐ MATCH!' : '❌'}</span>
        `).join('')}
      </div>
    `;
  }

  function renderPanel(state, playerNum, callbacks = {}, lastAttemptResult = null) {
    const panel = $('panel');
    if (!panel) return;

    // 1. Initial Lobby (Not in any room yet)
    if (!state || !state.roomCode) {
      panel.innerHTML = `
        <div class="modes">
          <p class="coin">READY PLAYER ONE</p>
          <div class="row" style="width:100%">
            <button class="btn alt" id="btnCreateRoom" style="flex:1">🎮 CREATE NEW GAME ROOM</button>
          </div>
          <p class="note">Want to join an existing room? Enter the 6-character room code below:</p>
          <div class="row" style="width:100%">
            <input id="inputJoinCode" class="in" type="text" maxlength="6" placeholder="e.g. TV1234" autocomplete="off" style="text-transform:uppercase">
            <button class="btn" id="btnJoinRoom">JOIN ROOM</button>
          </div>
        </div>
      `;
      $('btnCreateRoom').onclick = () => {
        const btn = $('btnCreateRoom');
        if (btn) {
          btn.disabled = true;
          btn.textContent = '⏳ CREATING ROOM...';
        }
        callbacks.onCreateRoom && callbacks.onCreateRoom();
      };
      $('btnJoinRoom').onclick = () => {
        const val = $('inputJoinCode').value.trim().toUpperCase();
        if (val) {
          const btn = $('btnJoinRoom');
          if (btn) {
            btn.disabled = true;
            btn.textContent = 'JOINING...';
          }
          callbacks.onJoinRoom && callbacks.onJoinRoom(val);
        } else {
          showToast('Please enter a room code (e.g. TV1234)');
        }
      };
      return;
    }

    // 2. Room Lobby (Waiting for Player 2 or ready to start)
    if (state.phase === 'LOBBY' || state.status === 'LOBBY' || state.status === 'READY') {
      const p1Connected = state.players && state.players[1] && state.players[1].connected;
      const p2Connected = state.players && state.players[2] && state.players[2].connected;
      const bothConnected = p1Connected && p2Connected;
      const isHost = playerNum === 1;
      const joinUrl = callbacks.getJoinUrl ? callbacks.getJoinUrl(state.roomCode) : `${window.location.origin}/#${state.roomCode}`;

      panel.innerHTML = `
        <div class="lob">
          <div class="qr-card">
            <div id="qr"></div>
            <div class="room-badge">ROOM ${esc(state.roomCode)}</div>
            <span>Scan on phone or share link</span>
          </div>

          <div class="modes">
            <p class="coin">${bothConnected ? '⭐ BOTH PLAYERS CONNECTED!' : '⏳ WAITING FOR PLAYER 2...'}</p>
            
            <!-- Working Invite Link Section -->
            <div class="invite-box">
              <label class="invite-label">INVITE LINK (SHARE WITH PLAYER 2):</label>
              <div class="row" style="width:100%; gap:8px;">
                <input type="text" id="inviteUrlInput" class="in invite-input" readonly value="${esc(joinUrl)}">
                <button class="btn alt" id="btnCopyLink">📋 COPY</button>
              </div>
              <div class="invite-links-bar">
                <a href="${esc(joinUrl)}" target="_blank" class="test-link" id="linkOpenTab">↗ Open in 2nd tab to test</a>
                <span class="hint" style="font-size:11px">• Room Code: <strong>${esc(state.roomCode)}</strong></span>
              </div>
            </div>

            <div class="player-slots">
              <div class="slot ${p1Connected ? 'filled' : ''}">
                <span>PLAYER 1 (HOST)</span>
                <span>${p1Connected ? '🟢 CONNECTED & READY' : '⚪ WAITING'}</span>
              </div>
              <div class="slot p2 ${p2Connected ? 'filled' : ''}">
                <span>PLAYER 2 (PARTNER)</span>
                <span>${p2Connected ? '🟢 CONNECTED' : '⚪ SCAN TO JOIN'}</span>
              </div>
            </div>

            ${isHost ? `
              <div class="row" style="width:100%">
                <button class="btn" id="btnStartGame" ${bothConnected ? '' : 'disabled'} style="flex:1">
                  ${bothConnected ? '🚀 ENTER THE TECH VERSE (START GAME)' : '⏳ WAITING FOR PLAYER 2 TO JOIN...'}
                </button>
              </div>
            ` : `
              <p class="hint" style="color:var(--cyan); margin-top:8px;">You are Player 2! Waiting for Host to start the game...</p>
            `}
          </div>
        </div>
      `;

      // Render QR code with resilience
      const qrEl = $('qr');
      if (qrEl) {
        qrEl.innerHTML = '';
        if (window.QRCode) {
          try {
            new window.QRCode(qrEl, {
              text: joinUrl,
              width: 140,
              height: 140,
              colorDark: '#120a2e',
              colorLight: '#ffffff'
            });
          } catch (e) {
            console.warn('QRCode render error:', e);
            renderQrFallback(qrEl, joinUrl);
          }
        } else {
          renderQrFallback(qrEl, joinUrl);
        }
      }

      function renderQrFallback(container, text) {
        container.innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=${encodeURIComponent(text)}" width="140" height="140" alt="QR Code for ${esc(state.roomCode)}" style="display:block;margin:0 auto">`;
      }

      // Copy invite link with multi-browser/LAN fallback
      const copyBtn = $('btnCopyLink');
      if (copyBtn) {
        copyBtn.onclick = () => {
          const input = $('inviteUrlInput');
          if (input) {
            input.focus();
            input.select();
            input.setSelectionRange(0, 99999);
          }

          const onCopied = () => {
            copyBtn.textContent = '✔ COPIED!';
            showToast('Invite link copied to clipboard!');
            setTimeout(() => { copyBtn.textContent = '📋 COPY'; }, 2000);
          };

          if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(joinUrl).then(onCopied).catch(() => {
              try {
                document.execCommand('copy');
                onCopied();
              } catch (e) {
                showToast('Please copy the URL from the input box above');
              }
            });
          } else {
            try {
              document.execCommand('copy');
              onCopied();
            } catch (e) {
              showToast('Please copy the URL from the input box above');
            }
          }
        };
      }

      const startBtn = $('btnStartGame');
      if (startBtn && isHost) {
        startBtn.onclick = () => callbacks.onStartGame && callbacks.onStartGame();
      }
      return;
    }

    // 3. Guessing Phase
    if (state.phase === 'GUESSING') {
      const isLocked = state.submissionsLocked && state.submissionsLocked[playerNum];
      const partnerLocked = state.submissionsLocked && state.submissionsLocked[playerNum === 1 ? 2 : 1];

      panel.innerHTML = `
        <p class="q">LEVEL ${state.currentLevel} OF 9 · ${esc(state.zone.name.toUpperCase())}</p>
        <p><strong>${esc(state.zone.question)}</strong> One word only.</p>
        <p class="hint" style="margin-top:-8px; margin-bottom:12px;">💡 ${esc(state.zone.hint)}</p>
        
        ${renderHistory(state.currentLevelAttempts)}

        ${isLocked ? `
          <div style="background:var(--deep); padding:16px; border-left:4px solid var(--cyan); margin-bottom:12px;">
            <p class="coin" style="color:var(--cyan); margin-bottom:6px;">🔒 ANSWER LOCKED IN!</p>
            <p class="hint" style="margin:0;">Waiting for your partner to lock in their word...</p>
          </div>
        ` : `
          <div class="row">
            <input id="inputWord" class="in" type="text" maxlength="32" autocomplete="off" placeholder="Type one word..." aria-label="Secret word">
            <button class="btn alt" id="btnLockWord">LOCK IN</button>
          </div>
          <p class="hint" id="wordHint" style="margin-top:8px;">
            ${partnerLocked ? '⚡ Your partner has locked in their answer!' : 'Your word remains secret until both players have locked in.'}
          </p>
        `}
      `;

      if (!isLocked) {
        const inEl = $('inputWord');
        const lockBtn = $('btnLockWord');
        if (inEl) inEl.focus();

        const doLock = () => {
          const w = inEl.value.trim();
          if (!w) {
            showToast('Type a word first!');
            return;
          }
          callbacks.onSubmitWord && callbacks.onSubmitWord(w);
        };

        if (lockBtn) lockBtn.onclick = doLock;
        if (inEl) {
          inEl.onkeydown = (e) => {
            if (e.key === 'Enter') doLock();
          };
        }
      }
      return;
    }

    // 4. Attempt Result (Mismatch - attempts remaining)
    if (state.phase === 'ATTEMPT_RESULT') {
      const last = lastAttemptResult || (state.currentLevelAttempts && state.currentLevelAttempts[state.currentLevelAttempts.length - 1]);
      panel.innerHTML = `
        <p class="res lose">NO MATCH · ATTEMPT ${state.currentAttempt - 1} OF 3</p>
        <p>
          Player 1 said <strong>“${esc(last ? last.p1Word : '')}”</strong>, 
          Player 2 said <strong>“${esc(last ? last.p2Word : '')}”</strong>.
        </p>
        <p class="hint">You have ${4 - state.currentAttempt} attempt(s) remaining for this zone. Discuss or align your thoughts!</p>
        ${renderHistory(state.currentLevelAttempts)}
        <div class="row">
          <button class="btn" id="btnNextAttempt">PROCEED TO ATTEMPT ${state.currentAttempt}</button>
        </div>
      `;
      $('btnNextAttempt').onclick = () => callbacks.onRequestNextAttempt && callbacks.onRequestNextAttempt();
      return;
    }

    // 5. Level Cleared Phase
    if (state.phase === 'LEVEL_CLEARED') {
      const last = lastAttemptResult || (state.currentLevelAttempts && state.currentLevelAttempts[state.currentLevelAttempts.length - 1]);
      panel.innerHTML = `
        <p class="res win">⭐ MATCH FOUND! LEVEL ${state.currentLevel - 1} CLEARED!</p>
        <p>You both synchronized on <strong>“${esc(last ? last.p1Word : '')}”</strong>!</p>
        ${renderHistory(state.currentLevelAttempts)}
        <div class="row">
          <button class="btn alt" id="btnNextLevel">ADVANCE TO LEVEL ${state.currentLevel}</button>
        </div>
      `;
      $('btnNextLevel').onclick = () => callbacks.onRequestNextLevel && callbacks.onRequestNextLevel();
      return;
    }

    // 6. DSA Challenge Phase
    if (state.phase === 'DSA_CHALLENGE') {
      const prob = state.assignedDsaProblem;
      if (!prob) {
        panel.innerHTML = '<p>Loading DSA challenge...</p>';
        return;
      }

      panel.innerHTML = `
        <div style="background:#3a0f1d; padding:12px 14px; border-left:4px solid var(--danger); margin-bottom:12px;">
          <p class="coin" style="color:var(--danger); margin:0;">🚨 3 WORD GUESSES EXHAUSTED (FAILED LEVEL ${state.failedLevels}/3)</p>
          <p style="margin:4px 0 0; font-size:14px; color:#ffb3ba;">
            Solve this DSA problem as a team in Python 3 to recover and clear this level!
          </p>
        </div>

        <div class="dsa-box">
          <div class="dsa-header">
            <h2 class="dsa-title">${esc(prob.title)}</h2>
            <span class="dsa-topic">${esc(prob.topic)} · ${esc(prob.difficulty)}</span>
          </div>

          <div class="dsa-desc">${esc(prob.description)}</div>

          <div class="dsa-meta">
            <strong>Input Format:</strong>
            <pre>${esc(prob.inputFormat)}</pre>
            <strong style="margin-top:6px; display:block">Output Format:</strong>
            <pre>${esc(prob.outputFormat)}</pre>
          </div>

          <div style="margin-bottom:10px;">
            <label style="font:400 10px var(--px); color:var(--cyan); display:block; margin-bottom:6px;">PYTHON 3 SOLUTION:</label>
            <textarea id="dsaCodeEditor" class="code-area" spellcheck="false">${esc(prob.starterCode || '')}</textarea>
          </div>

          <div id="dsaStatusBanner" class="dsa-status"></div>

          <div class="row">
            <button class="btn alt" id="btnSubmitDsa">⚡ RUN & SUBMIT SOLUTION</button>
          </div>
        </div>
      `;

      $('btnSubmitDsa').onclick = () => {
        const code = $('dsaCodeEditor').value;
        callbacks.onSubmitDsa && callbacks.onSubmitDsa(prob.id, code);
      };
      return;
    }

    // 7. Eliminated Phase
    if (state.phase === 'ELIMINATED' || state.status === 'ELIMINATED') {
      panel.innerHTML = `
        <div style="text-align:center; padding:18px 10px;">
          <p class="res lose" style="font-size:26px;">☠️ SYSTEM OVERLOAD · ELIMINATED</p>
          <p style="color:var(--danger); font:400 12px/1.6 var(--px);">
            ${esc(state.eliminationReason || 'Your team failed 3 different levels in the Tech Verse.')}
          </p>
          <p class="hint">The Tech Verse campus security systems locked you out. Try again with tighter synchronization!</p>
          <div class="row" style="justify-content:center; margin-top:20px;">
            <button class="btn alt" id="btnPlayAgain">🔄 RESTART NEW GAME</button>
          </div>
        </div>
      `;
      $('btnPlayAgain').onclick = () => callbacks.onPlayAgain && callbacks.onPlayAgain();
      return;
    }

    // 8. Victory Phase (All 9 Levels Cleared)
    if (state.phase === 'GAME_COMPLETED' || state.status === 'WON') {
      panel.innerHTML = `
        <div style="text-align:center; padding:18px 10px;">
          <p class="res win" style="font-size:28px;">🏆 TECH VERSE CONQUERED!</p>
          <p style="color:var(--sun); font:400 12px/1.6 var(--px);">MIND MELD MASTERS · ALL 9 LEVELS CLEARED!</p>
          <p class="hint">You and your partner completed every zone from the AI Lab to the Innovation Nexus!</p>
          <div class="row" style="justify-content:center; margin-top:20px;">
            <button class="btn alt" id="btnPlayAgain">🎮 PLAY AGAIN</button>
          </div>
        </div>
      `;
      $('btnPlayAgain').onclick = () => callbacks.onPlayAgain && callbacks.onPlayAgain();
    }
  }

  function showDsaResult(result) {
    const banner = $('dsaStatusBanner');
    if (!banner) return;

    if (result.success) {
      banner.className = 'dsa-status accepted';
      banner.textContent = `✔ ${result.message || 'Solution Accepted! Advancing team...'}`;
    } else {
      banner.className = 'dsa-status error';
      let msg = `✖ ${result.status}: ${result.message}`;
      if (result.failedCase && result.failedCase.isSample) {
        msg += ` (Input: ${result.failedCase.input} | Expected: ${result.failedCase.expected} | Got: ${result.failedCase.actual || 'Error'})`;
      }
      banner.textContent = msg;
    }
  }

  return {
    showToast,
    updateConnectionPill,
    renderHud,
    renderStrip,
    renderScene,
    renderPanel,
    showDsaResult
  };
})();
