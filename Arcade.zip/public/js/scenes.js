/**
 * Pixel Art SVG Scenes and Visual Effects for Arcade Arena · Tech Verse 2026
 * Renders retro 8-bit avatars, environments, and animations for all 9 zones.
 */

window.ArcadeScenes = (function () {
  const ZONES = [
    {
      level: 1,
      name: 'AI Lab',
      q: 'Name something you’d find in the AI Lab.',
      bg: '#1d2f5e',
      fl: '#2a1a5e',
      p: [
        [70, 50, 170, 100, '#31e8ff'],
        [80, 60, 150, 80, '#120a2e'],
        [100, 80, 60, 6, '#31e8ff'],
        [100, 96, 100, 6, '#ff3d9a'],
        [430, 40, 70, 160, '#4a3a8a'],
        [440, 56, 10, 10, '#ffd23f'],
        [440, 80, 10, 10, '#31e8ff'],
        [440, 104, 10, 10, '#ff3d9a'],
        [530, 150, 80, 50, '#4a3a8a']
      ]
    },
    {
      level: 2,
      name: 'Gaming Zone',
      q: 'Name something you’d find in the Gaming Zone.',
      bg: '#3a1060',
      fl: '#1b1040',
      p: [
        [60, 50, 80, 150, '#ff3d9a'],
        [70, 66, 60, 44, '#120a2e'],
        [160, 50, 80, 150, '#31e8ff'],
        [170, 66, 60, 44, '#120a2e'],
        [420, 40, 170, 26, '#ffd23f'],
        [450, 150, 110, 50, '#4a3a8a'],
        [470, 130, 70, 20, '#ff3d9a']
      ]
    },
    {
      level: 3,
      name: 'Robotics Bay',
      q: 'Name something you’d find in the Robotics Bay.',
      bg: '#153a4a',
      fl: '#20344a',
      p: [
        [290, 170, 70, 30, '#ffd23f'],
        [320, 90, 12, 86, '#ffd23f'],
        [300, 78, 50, 12, '#ffd23f'],
        [300, 90, 8, 24, '#ffd23f'],
        [342, 90, 8, 24, '#ffd23f'],
        [440, 140, 160, 60, '#4a3a8a'],
        [460, 120, 40, 20, '#31e8ff'],
        [60, 60, 120, 10, '#8a7ac8'],
        [60, 100, 120, 10, '#8a7ac8']
      ]
    },
    {
      level: 4,
      name: 'Code Café',
      q: 'Name something you’d find in the Code Café.',
      bg: '#4a2a3a',
      fl: '#3a2030',
      p: [
        [50, 130, 230, 70, '#8a5a3a'],
        [70, 106, 24, 24, '#fff'],
        [120, 106, 24, 24, '#fff'],
        [170, 100, 60, 30, '#31e8ff'],
        [380, 40, 190, 110, '#31e8ff'],
        [390, 50, 80, 90, '#7af2ff'],
        [560, 160, 30, 40, '#1f7a4a'],
        [550, 140, 50, 24, '#2fa86a']
      ]
    },
    {
      level: 5,
      name: 'Hardware Hub',
      q: 'Name a component you would find in the Hardware Hub.',
      bg: '#20344a',
      fl: '#1b2a3a',
      p: [
        [70, 50, 220, 130, '#1f7a4a'],
        [90, 70, 40, 40, '#120a2e'],
        [150, 70, 40, 40, '#120a2e'],
        [210, 76, 60, 6, '#ffd23f'],
        [210, 96, 60, 6, '#ffd23f'],
        [100, 130, 150, 6, '#ffd23f'],
        [430, 60, 150, 16, '#8a7ac8'],
        [430, 110, 150, 16, '#8a7ac8'],
        [440, 76, 20, 34, '#ff3d9a'],
        [490, 76, 20, 34, '#31e8ff']
      ]
    },
    {
      level: 6,
      name: 'Cybersecurity Chamber',
      q: 'Name something you’d find in the Cybersecurity Chamber.',
      bg: '#0f2b24',
      fl: '#0a1d18',
      p: [
        [50, 40, 120, 130, '#0d4a36'],
        [60, 50, 100, 110, '#051c14'],
        [70, 60, 80, 6, '#00ff9d'],
        [70, 72, 50, 6, '#31e8ff'],
        [70, 84, 70, 6, '#00ff9d'],
        [450, 40, 140, 140, '#1c4a3b'],
        [465, 55, 110, 110, '#0a1d18'],
        [490, 70, 60, 30, '#ff3d9a'],
        [505, 105, 30, 40, '#ffd23f'],
        [270, 140, 100, 50, '#123d2e']
      ]
    },
    {
      level: 7,
      name: 'Data Science Deck',
      q: 'Name something you’d find on the Data Science Deck.',
      bg: '#2d1b4e',
      fl: '#1a0e30',
      p: [
        [60, 60, 130, 120, '#431b6e'],
        [70, 120, 20, 50, '#ffd23f'],
        [95, 95, 20, 75, '#31e8ff'],
        [120, 75, 20, 95, '#ff3d9a'],
        [145, 110, 20, 60, '#a855f7'],
        [440, 40, 150, 150, '#3a1d63'],
        [455, 55, 120, 24, '#ffd23f'],
        [455, 90, 120, 24, '#31e8ff'],
        [455, 125, 120, 24, '#ff3d9a']
      ]
    },
    {
      level: 8,
      name: 'Cloud Computing Zone',
      q: 'Name something you’d find in the Cloud Computing Zone.',
      bg: '#123356',
      fl: '#09213a',
      p: [
        [70, 50, 140, 130, '#1a4975'],
        [85, 65, 110, 25, '#31e8ff'],
        [85, 100, 110, 25, '#ffd23f'],
        [85, 135, 110, 25, '#7af2ff'],
        [450, 50, 140, 130, '#1a4975'],
        [465, 65, 110, 25, '#31e8ff'],
        [465, 100, 110, 25, '#ffd23f'],
        [465, 135, 110, 25, '#7af2ff'],
        [270, 60, 100, 50, '#31e8ff']
      ]
    },
    {
      level: 9,
      name: 'Innovation Nexus',
      q: 'Name something you’d find at the Innovation Nexus.',
      bg: '#441434',
      fl: '#2d0c22',
      p: [
        [270, 30, 100, 160, '#6a1a4c'],
        [290, 50, 60, 120, '#ffd23f'],
        [305, 65, 30, 90, '#ffffff'],
        [60, 50, 120, 130, '#58163f'],
        [80, 70, 80, 90, '#ff3d9a'],
        [460, 50, 120, 130, '#58163f'],
        [480, 70, 80, 90, '#31e8ff']
      ]
    }
  ];

  function esc(s) {
    return String(s || '').replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  function R(a) {
    return `<rect x="${a[0]}" y="${a[1]}" width="${a[2]}" height="${a[3]}" fill="${a[4]}"/>`;
  }

  function person(x, col, txt, label, hit) {
    const displayTxt = txt.length > 11 ? txt.slice(0, 10) + '…' : txt;
    const bubbleColor = hit ? '#ffd23f' : '#ffffff';

    return `
      <g class="bub">
        <rect x="${x - 65}" y="84" width="130" height="42" fill="${bubbleColor}"/>
        <rect x="${x - 4}" y="126" width="8" height="8" fill="${bubbleColor}"/>
        <text x="${x}" y="111" text-anchor="middle" font-size="11" fill="#120a2e" style="font-family:var(--px)">${esc(displayTxt)}</text>
      </g>
      <g class="pp">
        ${R([x - 10, 148, 20, 20, '#ffd7b0'])}
        ${R([x - 10, 148, 20, 7, '#120a2e'])}
        ${R([x - 14, 168, 28, 32, col])}
        ${R([x - 12, 200, 10, 16, '#120a2e'])}
        ${R([x + 2, 200, 10, 16, '#120a2e'])}
      </g>
      <text x="${x}" y="244" text-anchor="middle" font-size="10" fill="#f2edff" style="font-family:var(--px)">${esc(label)}</text>
    `;
  }

  function renderScene({ zone, text1, text2, label1, label2, hit, isReveal }) {
    const z = zone || ZONES[0];
    const t1 = text1 || '?';
    const t2 = text2 || '?';
    const l1 = label1 || 'PLAYER 1';
    const l2 = label2 || 'PLAYER 2';

    let sceneClass = '';
    if (isReveal) {
      sceneClass = hit ? 'rev hit' : 'rev miss';
    }

    return `
      <svg class="${sceneClass}" viewBox="0 0 640 260" role="img" aria-label="${esc(z.name)}">
        ${R([0, 0, 640, 260, z.bg])}
        ${R([0, 200, 640, 60, z.fl])}
        ${R([0, 200, 640, 4, '#ff3d9a'])}
        ${z.p.map(R).join('')}
        <text x="14" y="26" font-size="11" fill="#ffd23f" style="font-family:var(--px)">${esc(z.name.toUpperCase())}</text>
        ${person(170, '#31e8ff', t1, l1, hit)}
        ${person(470, '#ff3d9a', t2, l2, hit)}
      </svg>
    `;
  }

  function burst() {
    const f = document.createElement('div');
    f.className = 'fx';
    f.setAttribute('aria-hidden', 'true');
    const cols = ['#ffd23f', '#ff3d9a', '#31e8ff', '#ffffff'];

    for (let i = 0; i < 48; i++) {
      const s = document.createElement('i');
      const w = 6 + Math.random() * 8;
      s.style.cssText = `left:${Math.random() * 100}%;background:${cols[i % 4]};--dx:${Math.random() * 160 - 80}px;--r:${Math.random() * 720 - 360}deg;animation-duration:${1.6 + Math.random() * 1.4}s;animation-delay:${Math.random() * 0.4}s;width:${w}px;height:${w}px`;
      f.appendChild(s);
    }

    document.body.appendChild(f);
    setTimeout(() => f.remove(), 3400);

    const sc = document.getElementById('scene');
    if (sc) {
      sc.classList.remove('flash');
      void sc.offsetWidth;
      sc.classList.add('flash');
    }
  }

  return {
    ZONES,
    renderScene,
    burst
  };
})();
