# 👾 ARCADE ARENA · TECH VERSE 2026
### Real-Time Two-Player Multiplayer Web Game with DSA Recovery Challenges

**Arcade Arena · Tech Verse 2026** is a retro arcade-styled, real-time multiplayer cooperative game. Two players connect from different devices (desktop, laptop, or mobile phones via QR code scan) to navigate through **nine unique tech environments** of the Tech Verse campus. In each zone, players must independently and secretly submit words they associate with that environment. If their normalized answers match, the zone is cleared! If they fail after three attempts, they must collaborate to solve an easy DSA coding challenge in Python 3 to recover and proceed. However, failing three different levels triggers immediate team elimination!

---

## 🚀 Key Features

1. **Retro Arcade Aesthetic Preserved**:
   - 8-bit typography (`Press Start 2P`, `Chakra Petch`), scanline overlay, neon glows, and animated speech bubbles.
   - Handcrafted pixel-art SVG scenes for all **9 levels**:
     - *Level 1: AI Lab*
     - *Level 2: Gaming Zone*
     - *Level 3: Robotics Bay*
     - *Level 4: Code Café*
     - *Level 5: Hardware Hub*
     - *Level 6: Cybersecurity Chamber*
     - *Level 7: Data Science Deck*
     - *Level 8: Cloud Computing Zone*
     - *Level 9: Innovation Nexus*

2. **Real-Time Multiplayer Synchronization**:
   - Powered by **Socket.IO** with authoritative server-side state.
   - Room-based isolation: strictly **2 players per room** (`TVxxxx`). Third player is rejected.
   - Secret submissions: words remain hidden until both players have locked in.
   - Normalized matching: case-insensitive, whitespace-trimmed, multi-space collapsed.

3. **3-Attempt Word Matching & Progression**:
   - Each level grants up to 3 secret word-guess attempts.
   - Resets to Attempt 1 upon advancing to each new level.

4. **DSA Challenge Recovery Phase**:
   - 16 built-in beginner-friendly DSA challenges designed for 1st-year CSE students.
   - Topics: Arrays, Strings, Linear Search, Palindromes, Fibonacci, Primes, Character Frequencies, Vowels, Extremes.
   - Embedded Python 3 code editor inside the retro arcade cabinet.
   - Real-time test-case validation with sample input/output checks and hidden validation tests.

5. **Strict Elimination Rule**:
   - A level is considered "failed" only when all 3 word guesses are exhausted.
   - **Maximum failed levels allowed is TWO.**
   - On the **3rd failed level**, the team is **immediately eliminated** without a DSA challenge.

6. **Persistent Game State & Seamless Reconnection**:
   - Persistent SQLite database via `better-sqlite3`.
   - Players receive unique session tokens stored in `sessionStorage`.
   - If a player refreshes their browser or experiences a brief network drop, their session and role (Player 1 or 2) are automatically restored without losing progress.

7. **Multi-Device & QR Code Join Support**:
   - Player 1 creates a room and receives a QR code and invite link.
   - Automatically detects LAN IP (e.g. `http://192.168.x.x:3000/#TV1234`) during local development so mobile phones on the same Wi-Fi network can scan and join instantly.
   - Supports `PUBLIC_URL` or `HOST_URL` for cloud hosting (Render, Railway, Fly.io, etc.).

---

## 🛠️ Technology Stack

- **Frontend**: HTML5, Vanilla CSS3 (Retro Arcade design tokens), JavaScript (ES6+), Socket.IO Client, QRCode.js.
- **Backend**: Node.js (v18+), Express.js, Socket.IO (v4).
- **Database**: SQLite with `better-sqlite3` (WAL mode enabled, parameterized queries).
- **Execution Engine**: Local isolated Python 3 subprocess evaluator with timeout and security controls.
- **Testing**: Mocha, Chai, Supertest, Socket.IO-Client (27 automated tests).

---

## 📋 Prerequisites

- **Node.js**: v18.0.0 or higher (Tested on v24)
- **npm**: v9.0.0 or higher
- **Python 3**: Python 3.8+ installed and available on PATH (`python3`) for running DSA solutions

---

## 📦 Installation & Setup

1. **Clone or navigate to the project directory**:
   ```bash
   cd Arcade_Arena
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Configure Environment Variables**:
   Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
   *(Defaults in `.env` work out of the box for local testing).*

---

## 🎮 How to Start the Backend

Start the server:
```bash
npm start
```
Or with development watch:
```bash
npm run dev
```

The terminal will display:
```
========================================================
🎮 ARCADE ARENA · TECH VERSE 2026 SERVER READY
🌐 Local URL:     http://localhost:3000
📱 Multiplayer:   http://<YOUR_LAN_IP>:3000
⚡ Environment:   development
========================================================
```

---

## 📱 How to Test with Two Devices

### Option A: Two Browser Windows / Tabs (Same Computer)
1. Open `http://localhost:3000` in your first browser window (Player 1).
2. Click **"🎮 CREATE NEW GAME ROOM"**.
3. You will see Room Code (e.g., `TV4821`), a QR code, and a **"📋 COPY INVITE LINK"** button.
4. Open an Incognito / Private window or another browser (Chrome, Firefox, Safari) and navigate to `http://localhost:3000/#TV4821` (or click Copy Invite Link and paste it).
5. Player 2 joins instantly!
6. On Player 1's screen, click **"🚀 ENTER THE TECH VERSE (START GAME)"**.
7. Both screens will begin Level 1 simultaneously.

### Option B: Mobile Phone + Laptop (Same Local Wi-Fi Network)
1. Ensure your laptop and phone are connected to the same Wi-Fi.
2. Start the server on your laptop with `npm start`.
3. Open `http://localhost:3000` on your laptop and click **"CREATE NEW GAME ROOM"**.
4. Point your mobile phone camera at the QR code displayed on the screen.
5. Tap the notification to open the link (e.g. `http://192.168.1.50:3000/#TV4821`).
6. Your phone joins as Player 2. Both devices are now live and synchronized!

---

## 🧪 Running Automated Tests

Run the full suite of automated tests:
```bash
npm test
```

### Verified Test Cases:
- **TEST 1**: Two players join the same room successfully.
- **TEST 2**: A third player cannot join a full room (`ROOM_FULL`).
- **TEST 3**: Both players submit the same word. The level clears.
- **TEST 4**: Answers differing only in capitalization match (e.g., `Robot` vs `robot`).
- **TEST 5**: One player submits but the other has not; no answer is revealed.
- **TEST 6**: Two different words produce a mismatch.
- **TEST 7**: The team gets exactly three attempts per level.
- **TEST 8**: The first failed level triggers a DSA challenge.
- **TEST 9**: The second failed level can still be recovered by solving DSA.
- **TEST 10**: The third failed level causes immediate elimination.
- **TEST 11**: An incorrect DSA solution fails with `WRONG_ANSWER` and does not advance.
- **TEST 12**: A correct DSA solution passes validation and advances the team.
- **TEST 13**: Refreshing a page does not reset the current level.
- **TEST 14**: A disconnected player can reconnect without losing progress.
- **TEST 15**: Level 9 completion produces the victory screen.
- **TEST 16**: The game never advances beyond Level 9.
- **TEST 17**: Duplicate submissions cannot advance the game twice.
- **TEST 18**: Two rooms operate independently without sharing state.
- **TEST 19**: Players cannot skip levels by modifying client-side data.
- **TEST 20**: The game cannot progress after elimination.

---

## 🌐 Deployment to Public Hosting

To deploy to hosting platforms like **Render**, **Railway**, **Fly.io**, or **Heroku**:

1. **Set Environment Variables** on your hosting dashboard:
   - `PORT`: Provided by host (e.g. `10000` or `$PORT`).
   - `NODE_ENV`: `production`
   - `PUBLIC_URL`: Your public domain (e.g., `https://arcade-arena.onrender.com`).
     *This ensures the QR code embeds the live HTTPS URL instead of localhost or LAN IP.*

2. **Build & Start Commands**:
   - Build Command: `npm install`
   - Start Command: `npm start`

3. **Data Persistence**:
   - For ephemeral hosts, mount a persistent volume to `/data` or specify `DB_PATH=/var/data/arcade_arena.db`.

---

## 🔒 DSA Evaluator Architecture & Production Hardening

### Development Evaluator
The built-in evaluator (`server/dsa/evaluator.js`) runs Python 3 in an isolated child process with:
- Execution timeout: **2500ms**
- Output size limit: **64 KB**
- Source code size limit: **16 KB**
- Process isolation flags: `python3 -I -B` (ignores site packages and environment variables)
- Static analysis blocking sensitive packages (`os.system`, `subprocess`, `socket`, `pty`, `shutil`)

### Replacing with a Sandboxed Service in Production
For high-traffic public deployments, you can replace the local runner with **Judge0** or **Piston**:
1. In `server/dsa/evaluator.js`, replace `runPythonCode()` with an HTTP request to the Judge0 API (`https://judge0-ce.p.rapidapi.com/submissions`).
2. Send `source_code`, `language_id` (71 for Python 3), and `stdin`.
3. Compare the returned `stdout` against `test.expected`.
4. Return standardized `{ success, status, message, failedCase }`.

---

## 📂 Project Structure

```
Arcade_Arena/
├── package.json               # Dependencies & scripts
├── .env.example               # Environment variables template
├── .gitignore                 # Git ignore file
├── README.md                  # Complete documentation
├── public/                    # Frontend client assets
│   ├── index.html             # Retro arcade cabinet HTML
│   ├── css/
│   │   └── style.css          # Retro arcade styles, scanlines, HUD & DSA styling
│   └── js/
│       ├── scenes.js          # SVG pixel-art scene generators (9 environments)
│       ├── socketClient.js    # Socket.IO client & session recovery
│       ├── ui.js              # HUD, panel, and DOM render controller
│       └── game.js            # Main client state & event coordinator
├── server/                    # Backend application
│   ├── server.js              # Entry point & HTTP/Socket server
│   ├── app.js                 # Express routes, static hosting, LAN IP detection
│   ├── socket.js              # Socket.IO multiplayer coordinator
│   ├── database.js            # SQLite database schema & queries
│   ├── gameManager.js         # Authoritative state machine & level progression
│   ├── gameRules.js           # Business rules, word normalization & 9 zones
│   ├── roomManager.js         # 2-player capacity, session tokens & reconnections
│   ├── dsa/
│   │   ├── problems.js        # Bank of 16 beginner DSA problems
│   │   └── evaluator.js       # Python 3 code execution sandbox & runner
│   └── middleware/
│       ├── validation.js      # Input sanitization & room validation
│       └── rateLimit.js       # Rate limiting middleware
├── tests/                     # Automated test suites
│   ├── gameRules.test.js      # Game rules & normalization unit tests
│   ├── dsa.test.js            # DSA problem bank & evaluator tests
│   ├── multiplayer.test.js    # 20 integration acceptance tests
│   ├── socket.test.js         # Real-time socket connection tests
│   └── e2eSimulation.js       # Live 2-player end-to-end simulation
└── data/                      # SQLite database storage (arcade_arena.db)
```

---

## 🏆 Final Acceptance Checklist

- [x] Authoritative real-time 2-player multiplayer room system.
- [x] QR code generation pointing to accessible join URL.
- [x] Secret word submission: no player's answer revealed before both submit.
- [x] Normalized word matching (case-insensitive, whitespace-trimmed).
- [x] Exactly 9 distinct Tech Verse levels with retro pixel-art visual scenes.
- [x] 3 word-guess attempts per level (resetting on level advance).
- [x] Failure after 3 attempts triggers beginner DSA recovery challenge.
- [x] 16 easy DSA problems bank with sample & hidden test cases.
- [x] Safe Python 3 code execution sandbox with timeout.
- [x] Strict 3-failed-level elimination rule (no DSA on 3rd failed level).
- [x] Victory upon clearing Level 9 (no 10th level).
- [x] Persistent SQLite database & session recovery on refresh/disconnect.
- [x] 27 automated tests passing.
