/**
 * Server Entry Point for Arcade Arena · Tech Verse 2026
 */

require('dotenv').config();
const http = require('http');
const { app, getBaseUrl } = require('./app');
const { setupSocketIO } = require('./socket');
const { initDatabase } = require('./database');

// Initialize SQLite database
initDatabase();

const server = http.createServer(app);

// Setup Socket.IO
const io = setupSocketIO(server, getBaseUrl);

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || '0.0.0.0';

server.listen(PORT, HOST, () => {
  const baseUrl = getBaseUrl();
  console.log('========================================================');
  console.log('🎮 ARCADE ARENA · TECH VERSE 2026 SERVER READY');
  console.log(`🌐 Local URL:     http://localhost:${PORT}`);
  console.log(`📱 Multiplayer:   ${baseUrl}`);
  console.log(`⚡ Environment:   ${process.env.NODE_ENV || 'development'}`);
  console.log('========================================================');
});

module.exports = { server, io };
