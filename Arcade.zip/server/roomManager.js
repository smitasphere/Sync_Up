/**
 * Room and Player Session Manager for Arcade Arena · Tech Verse 2026
 * Handles room lifecycle, 2-player capacity, session tokens, and reconnections.
 */

const crypto = require('crypto');
const db = require('./database');

// In-memory active rooms cache for fast live state access
const activeRooms = new Map();

// Room expiration time (default 2 hours)
const ROOM_EXPIRY_MS = parseInt(process.env.ROOM_EXPIRY_MS, 10) || 2 * 60 * 60 * 1000;

function generateRoomCode() {
  let code;
  let attempts = 0;
  do {
    // Generate TV followed by 4 random digits (e.g. TV8291)
    const num = Math.floor(1000 + Math.random() * 9000);
    code = `TV${num}`;
    attempts++;
  } while ((activeRooms.has(code) || db.getRoomByCode(code)) && attempts < 100);
  return code;
}

function generateSessionToken() {
  return crypto.randomBytes(16).toString('hex');
}

/**
 * Creates a new game room and assigns Player 1 (the host).
 */
function createRoom({ playerName } = {}) {
  const roomCode = generateRoomCode();
  const roomRecord = db.createRoomInDb(roomCode);

  const sessionToken = generateSessionToken();
  const player1 = db.addPlayerToDb({
    roomId: roomRecord.id,
    playerNum: 1,
    sessionToken,
    playerName: playerName || 'Player 1'
  });

  const room = {
    id: roomRecord.id,
    code: roomCode,
    status: 'LOBBY',
    phase: 'LOBBY',
    currentLevel: 1,
    currentAttempt: 1,
    failedLevels: 0,
    assignedDsaProblemId: null,
    winner: 0,
    eliminationReason: null,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    players: {
      1: {
        id: player1.id,
        playerNum: 1,
        sessionToken,
        socketId: null,
        name: player1.player_name,
        connected: false
      },
      2: null
    },
    // Submissions for the current attempt
    currentSubmissions: {
      1: null,
      2: null
    },
    assignedDsaHistory: []
  };

  activeRooms.set(roomCode, room);
  return { room, player: room.players[1] };
}

/**
 * Gets an active room by code (loads from SQLite if not currently in memory).
 */
function getRoom(roomCode) {
  if (!roomCode) return null;
  const upperCode = roomCode.toUpperCase();
  if (activeRooms.has(upperCode)) {
    return activeRooms.get(upperCode);
  }

  // Attempt recovery from SQLite
  const dbRoom = db.getRoomByCode(upperCode);
  if (!dbRoom) return null;

  const dbPlayers = db.getPlayersForRoom(dbRoom.id);
  const players = { 1: null, 2: null };

  for (const p of dbPlayers) {
    players[p.player_num] = {
      id: p.id,
      playerNum: p.player_num,
      sessionToken: p.session_token,
      socketId: p.socket_id,
      name: p.player_name,
      connected: !!p.is_connected
    };
  }

  const room = {
    id: dbRoom.id,
    code: dbRoom.room_code,
    status: dbRoom.status,
    phase: dbRoom.current_phase,
    currentLevel: dbRoom.current_level,
    currentAttempt: dbRoom.current_attempt,
    failedLevels: dbRoom.failed_levels,
    assignedDsaProblemId: dbRoom.assigned_dsa_problem_id,
    winner: dbRoom.winner,
    eliminationReason: dbRoom.elimination_reason,
    createdAt: new Date(dbRoom.created_at).getTime(),
    updatedAt: new Date(dbRoom.updated_at).getTime(),
    players,
    currentSubmissions: { 1: null, 2: null },
    assignedDsaHistory: dbRoom.assigned_dsa_problem_id ? [dbRoom.assigned_dsa_problem_id] : []
  };

  activeRooms.set(upperCode, room);
  return room;
}

/**
 * Adds Player 2 to an existing room.
 */
function joinRoom(roomCode, { playerName, sessionToken } = {}) {
  const room = getRoom(roomCode);
  if (!room) {
    return { success: false, error: 'ROOM_NOT_FOUND', message: 'Room not found.' };
  }

  if (room.status === 'ELIMINATED' || room.status === 'WON') {
    return { success: false, error: 'ROOM_FINISHED', message: 'This game has already concluded.' };
  }

  // If a sessionToken was supplied, check if this is an existing player reconnecting
  if (sessionToken) {
    const reconnectResult = reconnectPlayer(roomCode, sessionToken);
    if (reconnectResult.success) {
      return reconnectResult;
    }
  }

  // Check if room is already full (has both Player 1 and Player 2)
  if (room.players[1] && room.players[2]) {
    return { success: false, error: 'ROOM_FULL', message: 'Room is full. Arcade Arena supports exactly 2 players.' };
  }

  // Assign Player 2
  const token = generateSessionToken();
  const player2 = db.addPlayerToDb({
    roomId: room.id,
    playerNum: 2,
    sessionToken: token,
    playerName: playerName || 'Player 2'
  });

  room.players[2] = {
    id: player2.id,
    playerNum: 2,
    sessionToken: token,
    socketId: null,
    name: player2.player_name,
    connected: false
  };

  room.status = 'READY';
  room.updatedAt = Date.now();
  db.updateRoomStateInDb(room.id, { status: 'READY' });

  return { success: true, room, player: room.players[2], isNewPlayer: true };
}

/**
 * Reconnects an existing player using their session token.
 */
function reconnectPlayer(roomCode, sessionToken, socketId = null) {
  const room = getRoom(roomCode);
  if (!room) {
    return { success: false, error: 'ROOM_NOT_FOUND', message: 'Room not found.' };
  }

  let matchedPlayer = null;
  if (room.players[1] && room.players[1].sessionToken === sessionToken) {
    matchedPlayer = room.players[1];
  } else if (room.players[2] && room.players[2].sessionToken === sessionToken) {
    matchedPlayer = room.players[2];
  }

  if (!matchedPlayer) {
    return { success: false, error: 'INVALID_SESSION', message: 'Session token does not match this room.' };
  }

  matchedPlayer.connected = true;
  if (socketId) matchedPlayer.socketId = socketId;
  db.updatePlayerConnection(sessionToken, true, socketId);

  return { success: true, room, player: matchedPlayer, isReconnect: true };
}

/**
 * Marks player disconnected on socket leave / disconnect.
 */
function handlePlayerDisconnect(socketId) {
  for (const room of activeRooms.values()) {
    for (const num of [1, 2]) {
      const p = room.players[num];
      if (p && p.socketId === socketId) {
        p.connected = false;
        db.updatePlayerConnection(p.sessionToken, false);
        return { room, playerNum: num };
      }
    }
  }
  return null;
}

/**
 * Cleans up abandoned or expired rooms periodically.
 */
function cleanupExpiredRooms() {
  const now = Date.now();
  for (const [code, room] of activeRooms.entries()) {
    if (now - room.updatedAt > ROOM_EXPIRY_MS) {
      activeRooms.delete(code);
    }
  }
}

setInterval(cleanupExpiredRooms, 15 * 60 * 1000);

module.exports = {
  createRoom,
  getRoom,
  joinRoom,
  reconnectPlayer,
  handlePlayerDisconnect,
  generateRoomCode,
  activeRooms
};
