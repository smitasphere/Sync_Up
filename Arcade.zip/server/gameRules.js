/**
 * Game Rules and Constants for Arcade Arena · Tech Verse 2026
 * Authoritative business logic for levels, attempts, normalization, and elimination.
 */

const MAX_LEVELS = 9;
const MAX_ATTEMPTS_PER_LEVEL = 3;
const MAX_FAILED_LEVELS = 3; // 3 failed levels = immediate elimination
const MAX_WORD_LENGTH = 32;

// 9 Environments representing the Tech Verse campus
const ZONES = [
  {
    level: 1,
    name: 'AI Lab',
    question: 'Name something you’d find in the AI Lab.',
    bg: '#1d2f5e',
    fl: '#2a1a5e',
    hint: 'Think about machine learning models, robots, chips, neural networks...'
  },
  {
    level: 2,
    name: 'Gaming Zone',
    question: 'Name something you’d find in the Gaming Zone.',
    bg: '#3a1060',
    fl: '#1b1040',
    hint: 'Think about controllers, joysticks, arcade cabinets, coins, headsets...'
  },
  {
    level: 3,
    name: 'Robotics Bay',
    question: 'Name something you’d find in the Robotics Bay.',
    bg: '#153a4a',
    fl: '#20344a',
    hint: 'Think about robotic arms, sensors, motors, gears, microcontrollers...'
  },
  {
    level: 4,
    name: 'Code Café',
    question: 'Name something you’d find in the Code Café.',
    bg: '#4a2a3a',
    fl: '#3a2030',
    hint: 'Think about coffee, laptops, wifi, mugs, snacks, bug fixes...'
  },
  {
    level: 5,
    name: 'Hardware Hub',
    question: 'Name a component you would find in the Hardware Hub.',
    bg: '#20344a',
    fl: '#1b2a3a',
    hint: 'Think about solder, breadboards, resistors, chips, wires, multimeters...'
  },
  {
    level: 6,
    name: 'Cybersecurity Chamber',
    question: 'Name something you’d find in the Cybersecurity Chamber.',
    bg: '#0f2b24',
    fl: '#0a1d18',
    hint: 'Think about firewalls, encryption keys, tokens, ciphers, terminals...'
  },
  {
    level: 7,
    name: 'Data Science Deck',
    question: 'Name something you’d find on the Data Science Deck.',
    bg: '#2d1b4e',
    fl: '#1a0e30',
    hint: 'Think about datasets, graphs, dashboards, statistics, algorithms...'
  },
  {
    level: 8,
    name: 'Cloud Computing Zone',
    question: 'Name something you’d find in the Cloud Computing Zone.',
    bg: '#123356',
    fl: '#09213a',
    hint: 'Think about servers, clusters, containers, storage buckets, nodes...'
  },
  {
    level: 9,
    name: 'Innovation Nexus',
    question: 'Name something you’d find at the Innovation Nexus.',
    bg: '#441434',
    fl: '#2d0c22',
    hint: 'Think about prototypes, patents, quantum cores, holograms, pitch decks...'
  }
];

const PHASES = {
  LOBBY: 'LOBBY',
  WAITING_FOR_PLAYERS: 'WAITING_FOR_PLAYERS',
  READY: 'READY',
  LEVEL_INTRO: 'LEVEL_INTRO',
  GUESSING: 'GUESSING',
  ATTEMPT_RESULT: 'ATTEMPT_RESULT',
  DSA_CHALLENGE: 'DSA_CHALLENGE',
  LEVEL_CLEARED: 'LEVEL_CLEARED',
  ELIMINATED: 'ELIMINATED',
  GAME_COMPLETED: 'GAME_COMPLETED'
};

/**
 * Normalizes a word guess submission:
 * - strips leading/trailing whitespace
 * - converts to lowercase
 * - collapses consecutive internal whitespace to a single space
 * - limits max length
 */
function normalizeWord(word) {
  if (typeof word !== 'string') return '';
  return word
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .slice(0, MAX_WORD_LENGTH);
}

/**
 * Evaluates whether two words match according to the game rules.
 */
function wordsMatch(word1, word2) {
  const norm1 = normalizeWord(word1);
  const norm2 = normalizeWord(word2);
  if (!norm1 || !norm2) return false;
  return norm1 === norm2;
}

/**
 * Validates a word submission.
 */
function validateWordSubmission(word) {
  if (!word || typeof word !== 'string') {
    return { valid: false, error: 'Word cannot be empty' };
  }
  const cleaned = word.trim();
  if (cleaned.length === 0) {
    return { valid: false, error: 'Word cannot be empty' };
  }
  if (cleaned.length > MAX_WORD_LENGTH) {
    return { valid: false, error: `Word cannot exceed ${MAX_WORD_LENGTH} characters` };
  }
  return { valid: true, cleaned };
}

/**
 * Retrieves environment data for a given level (1 to 9).
 */
function getZoneForLevel(level) {
  if (level < 1 || level > MAX_LEVELS) return null;
  return ZONES[level - 1];
}

module.exports = {
  MAX_LEVELS,
  MAX_ATTEMPTS_PER_LEVEL,
  MAX_FAILED_LEVELS,
  MAX_WORD_LENGTH,
  ZONES,
  PHASES,
  normalizeWord,
  wordsMatch,
  validateWordSubmission,
  getZoneForLevel
};
