/**
 * Real-Time Socket.IO Multiplayer System for Arcade Arena · Tech Verse 2026
 * Authoritative synchronization for 2 players across all 9 levels.
 */

const { Server } = require('socket.io');
const roomManager = require('./roomManager');
const gameManager = require('./gameManager');
const db = require('./database');
const { sanitizeInput } = require('./middleware/validation');

function setupSocketIO(httpServer, getBaseUrl) {
  const io = new Server(httpServer, {
    cors: {
      origin: '*',
      methods: ['GET', 'POST']
    },
    pingInterval: 10000,
    pingTimeout: 5000
  });

  io.on('connection', (socket) => {
    // ---------------- Create Room ----------------
    socket.on('create_room', (data, callback) => {
      try {
        const rawName = (data && data.playerName) || 'Player 1';
        const playerName = sanitizeInput(rawName, 20);
        const { room, player } = roomManager.createRoom({ playerName });

        player.socketId = socket.id;
        player.connected = true;
        db.updatePlayerConnection(player.sessionToken, true, socket.id);
        socket.join(room.code);

        const baseUrl = getBaseUrl();
        const joinUrl = `${baseUrl}/#${room.code}`;
        const gameState = gameManager.getSafeGameState(room);

        console.log(`[Socket] Room created: ${room.code} for Player 1 (socket: ${socket.id})`);

        const payload = {
          success: true,
          roomId: room.id,
          roomCode: room.code,
          sessionToken: player.sessionToken,
          playerNum: 1,
          playerName: player.name,
          joinUrl,
          gameState
        };

        socket.emit('room_created', payload);
        if (typeof callback === 'function') callback(payload);
      } catch (err) {
        console.error('Socket create_room error:', err);
        socket.emit('error_message', { error: 'CREATE_FAILED', message: 'Failed to create room.' });
      }
    });

    // ---------------- Join Room ----------------
    socket.on('join_room', (data, callback) => {
      try {
        const roomCode = (data && data.roomId) ? data.roomId.toUpperCase().trim() : '';
        const sessionToken = data && data.sessionToken;
        const rawName = (data && data.playerName) || 'Player 2';
        const playerName = sanitizeInput(rawName, 20);

        if (!roomCode) {
          const errRes = { error: 'INVALID_ROOM', message: 'Room code is required.' };
          socket.emit('error_message', errRes);
          if (typeof callback === 'function') callback({ success: false, ...errRes });
          return;
        }

        const joinResult = roomManager.joinRoom(roomCode, { playerName, sessionToken });

        if (!joinResult.success) {
          if (joinResult.error === 'ROOM_FULL') {
            socket.emit('room_full', { message: joinResult.message });
          } else {
            socket.emit('error_message', { error: joinResult.error, message: joinResult.message });
          }
          if (typeof callback === 'function') callback(joinResult);
          return;
        }

        const { room, player, isReconnect } = joinResult;
        player.socketId = socket.id;
        player.connected = true;
        db.updatePlayerConnection(player.sessionToken, true, socket.id);
        socket.join(room.code);
        console.log(`[Socket] Room joined: ${room.code} by Player ${player.playerNum} (socket: ${socket.id}, reconnect: ${!!isReconnect})`);

        const gameState = gameManager.getSafeGameState(room);

        const payload = {
          success: true,
          roomId: room.id,
          roomCode: room.code,
          sessionToken: player.sessionToken,
          playerNum: player.playerNum,
          playerName: player.name,
          isHost: player.playerNum === 1,
          isReconnect: !!isReconnect,
          gameState
        };

        socket.emit('room_joined', payload);

        if (isReconnect) {
          socket.to(room.code).emit('player_reconnected', {
            playerNum: player.playerNum,
            playerName: player.name,
            gameState
          });
        } else {
          // Player 2 newly joined!
          io.to(room.code).emit('player_joined', {
            playerNum: player.playerNum,
            playerName: player.name,
            gameState
          });

          if (room.players[1] && room.players[2]) {
            io.to(room.code).emit('game_ready', {
              message: 'Both players connected! Host can start the game.',
              gameState
            });
          }
        }

        if (typeof callback === 'function') callback(payload);
      } catch (err) {
        console.error('Socket join_room error:', err);
        socket.emit('error_message', { error: 'JOIN_FAILED', message: 'Failed to join room.' });
      }
    });

    // ---------------- Start Game (Host Only) ----------------
    socket.on('start_game', (data, callback) => {
      try {
        const roomCode = (data && data.roomId) ? data.roomId.toUpperCase().trim() : '';
        const sessionToken = data && data.sessionToken;

        const room = roomManager.getRoom(roomCode);
        if (!room) {
          socket.emit('error_message', { error: 'ROOM_NOT_FOUND', message: 'Room not found.' });
          return;
        }

        const result = gameManager.startGame(room, sessionToken);
        if (!result.success) {
          socket.emit('error_message', { error: result.error, message: result.message });
          if (typeof callback === 'function') callback(result);
          return;
        }

        io.to(room.code).emit('game_started', {
          message: 'Tech Verse 2026 Begins!',
          gameState: result.gameState
        });

        if (typeof callback === 'function') callback(result);
      } catch (err) {
        console.error('Socket start_game error:', err);
        socket.emit('error_message', { error: 'START_FAILED', message: 'Failed to start game.' });
      }
    });

    // ---------------- Submit Word Guess ----------------
    socket.on('submit_word', (data, callback) => {
      try {
        const roomCode = (data && data.roomId) ? data.roomId.toUpperCase().trim() : '';
        const sessionToken = data && data.sessionToken;
        const rawWord = data && data.word;

        const room = roomManager.getRoom(roomCode);
        if (!room) {
          socket.emit('error_message', { error: 'ROOM_NOT_FOUND', message: 'Room not found.' });
          return;
        }

        const result = gameManager.submitWord(room, sessionToken, rawWord);
        if (!result.success) {
          socket.emit('error_message', { error: result.error, message: result.message });
          if (typeof callback === 'function') callback(result);
          return;
        }

        if (!result.bothSubmitted) {
          // Notify the submitting player that their answer is locked
          socket.emit('waiting_for_partner', {
            message: 'ANSWER LOCKED. WAITING FOR YOUR PARTNER...',
            playerNum: result.playerNum,
            gameState: result.gameState
          });

          // Notify partner that opponent locked in their answer (WITHOUT revealing the word)
          socket.to(room.code).emit('answer_locked', {
            message: `Player ${result.playerNum} has locked in their answer!`,
            playerNum: result.playerNum,
            gameState: result.gameState
          });

          if (typeof callback === 'function') callback({ success: true, waiting: true });
          return;
        }

        // BOTH PLAYERS HAVE SUBMITTED!
        if (result.isMatch) {
          // LEVEL CLEARED OR GAME WON!
          io.to(room.code).emit('attempt_result', {
            isMatch: true,
            p1Word: result.p1Word,
            p2Word: result.p2Word,
            attemptNum: result.attemptNum,
            gameState: result.gameState
          });

          if (result.isGameWon) {
            io.to(room.code).emit('level_cleared', {
              clearedLevel: result.clearedLevel,
              isGameWon: true,
              gameState: result.gameState
            });
            io.to(room.code).emit('game_completed', {
              message: 'VICTORY! All 9 levels of Tech Verse cleared!',
              gameState: result.gameState
            });
          } else {
            io.to(room.code).emit('level_cleared', {
              clearedLevel: result.clearedLevel,
              nextLevel: result.nextLevel,
              isGameWon: false,
              gameState: result.gameState
            });
          }
        } else {
          // MISMATCH!
          if (result.isEliminated) {
            // 3 FAILED LEVELS -> ELIMINATED!
            io.to(room.code).emit('attempt_result', {
              isMatch: false,
              attemptsExhausted: true,
              isEliminated: true,
              p1Word: result.p1Word,
              p2Word: result.p2Word,
              failedLevels: result.failedLevels,
              gameState: result.gameState
            });

            io.to(room.code).emit('player_eliminated', {
              reason: result.eliminationReason,
              failedLevels: result.failedLevels,
              gameState: result.gameState
            });
          } else if (result.attemptsExhausted) {
            // 3 attempts exhausted on this level, but failedLevels < 3 -> DSA CHALLENGE!
            io.to(room.code).emit('attempt_result', {
              isMatch: false,
              attemptsExhausted: true,
              isEliminated: false,
              p1Word: result.p1Word,
              p2Word: result.p2Word,
              failedLevels: result.failedLevels,
              gameState: result.gameState
            });

            io.to(room.code).emit('dsa_challenge_started', {
              message: 'All 3 word guesses exhausted! Solve the DSA challenge to recover!',
              dsaProblem: result.dsaProblem,
              failedLevels: result.failedLevels,
              gameState: result.gameState
            });
          } else {
            // Attempts still remaining for this level
            io.to(room.code).emit('attempt_result', {
              isMatch: false,
              attemptsExhausted: false,
              p1Word: result.p1Word,
              p2Word: result.p2Word,
              failedAttempt: result.failedAttempt,
              remainingAttempts: result.remainingAttempts,
              nextAttemptNum: result.nextAttemptNum,
              gameState: result.gameState
            });
          }
        }

        if (typeof callback === 'function') callback({ success: true, evaluated: true });
      } catch (err) {
        console.error('Socket submit_word error:', err);
        socket.emit('error_message', { error: 'SUBMISSION_FAILED', message: 'Failed to process submission.' });
      }
    });

    // ---------------- Request Next Attempt ----------------
    socket.on('request_next_attempt', (data, callback) => {
      try {
        const roomCode = (data && data.roomId) ? data.roomId.toUpperCase().trim() : '';
        const room = roomManager.getRoom(roomCode);
        if (!room) return;

        const result = gameManager.proceedToNextAttempt(room);
        if (result.success) {
          io.to(room.code).emit('game_state', { gameState: result.gameState });
        }
        if (typeof callback === 'function') callback(result);
      } catch (err) {
        console.error('Socket request_next_attempt error:', err);
      }
    });

    // ---------------- Request Next Level ----------------
    socket.on('request_next_level', (data, callback) => {
      try {
        const roomCode = (data && data.roomId) ? data.roomId.toUpperCase().trim() : '';
        const room = roomManager.getRoom(roomCode);
        if (!room) return;

        const result = gameManager.proceedToNextLevel(room);
        if (result.success) {
          io.to(room.code).emit('level_started', { gameState: result.gameState });
        }
        if (typeof callback === 'function') callback(result);
      } catch (err) {
        console.error('Socket request_next_level error:', err);
      }
    });

    // ---------------- Submit DSA Solution ----------------
    socket.on('submit_dsa_solution', async (data, callback) => {
      try {
        const roomCode = (data && data.roomId) ? data.roomId.toUpperCase().trim() : '';
        const sessionToken = data && data.sessionToken;
        const problemId = data && data.problemId;
        const code = data && data.code;
        const language = (data && data.language) || 'python';

        const room = roomManager.getRoom(roomCode);
        if (!room) {
          socket.emit('error_message', { error: 'ROOM_NOT_FOUND', message: 'Room not found.' });
          return;
        }

        const result = await gameManager.submitDsaSolution(room, sessionToken, problemId, code, language);

        if (!result.success) {
          // Submission did not pass
          io.to(room.code).emit('dsa_submission_result', {
            success: false,
            status: result.status,
            message: result.message,
            playerNum: result.playerNum,
            failedCase: result.failedCase || null,
            gameState: result.gameState
          });
          if (typeof callback === 'function') callback(result);
          return;
        }

        // DSA SOLUTION ACCEPTED!
        io.to(room.code).emit('dsa_submission_result', {
          success: true,
          status: 'ACCEPTED',
          message: `Player ${result.playerNum} solved the DSA challenge! Level cleared!`,
          playerNum: result.playerNum,
          clearedLevel: result.clearedLevel,
          isGameWon: result.isGameWon,
          gameState: result.gameState
        });

        if (result.isGameWon) {
          io.to(room.code).emit('level_cleared', {
            clearedLevel: result.clearedLevel,
            isGameWon: true,
            gameState: result.gameState
          });
          io.to(room.code).emit('game_completed', {
            message: 'VICTORY! All 9 levels of Tech Verse cleared!',
            gameState: result.gameState
          });
        } else {
          io.to(room.code).emit('level_cleared', {
            clearedLevel: result.clearedLevel,
            nextLevel: result.nextLevel,
            isGameWon: false,
            gameState: result.gameState
          });
        }

        if (typeof callback === 'function') callback(result);
      } catch (err) {
        console.error('Socket submit_dsa_solution error:', err);
        socket.emit('error_message', { error: 'DSA_FAILED', message: 'Error evaluating DSA submission.' });
      }
    });

    // ---------------- Request Current Game State ----------------
    socket.on('request_game_state', (data, callback) => {
      try {
        const roomCode = (data && data.roomId) ? data.roomId.toUpperCase().trim() : '';
        const room = roomManager.getRoom(roomCode);
        if (room) {
          const state = gameManager.getSafeGameState(room);
          socket.emit('game_state', { gameState: state });
          if (typeof callback === 'function') callback({ success: true, gameState: state });
        } else {
          socket.emit('error_message', { error: 'ROOM_NOT_FOUND', message: 'Room not found.' });
        }
      } catch (err) {
        console.error('Socket request_game_state error:', err);
      }
    });

    // ---------------- Disconnect Handler ----------------
    socket.on('disconnect', () => {
      const disc = roomManager.handlePlayerDisconnect(socket.id);
      if (disc) {
        const { room, playerNum } = disc;
        socket.to(room.code).emit('player_disconnected', {
          playerNum,
          message: `Player ${playerNum} disconnected. Waiting for reconnection...`
        });
      }
    });
  });

  return io;
}

module.exports = { setupSocketIO };
