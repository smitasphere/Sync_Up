/**
 * Database Module for Arcade Arena · Tech Verse 2026
 * SQLite database setup and parameterized queries using better-sqlite3.
 */

const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'arcade_arena.db');

// Ensure data directory exists
const dataDir = path.dirname(DB_PATH);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

let db = null;

function initDatabase(customPath) {
  const file = customPath || DB_PATH;
  db = new Database(file);

  // Enable WAL mode for better concurrency and foreign keys
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  // Schema creation
  db.exec(`
    CREATE TABLE IF NOT EXISTS rooms (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_code TEXT UNIQUE NOT NULL,
      status TEXT NOT NULL DEFAULT 'LOBBY',
      current_level INTEGER NOT NULL DEFAULT 1,
      current_attempt INTEGER NOT NULL DEFAULT 1,
      failed_levels INTEGER NOT NULL DEFAULT 0,
      current_phase TEXT NOT NULL DEFAULT 'LOBBY',
      assigned_dsa_problem_id TEXT,
      winner INTEGER NOT NULL DEFAULT 0,
      elimination_reason TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS players (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
      player_num INTEGER NOT NULL,
      session_token TEXT UNIQUE NOT NULL,
      socket_id TEXT,
      player_name TEXT DEFAULT 'Player',
      is_connected INTEGER NOT NULL DEFAULT 1,
      joined_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_active_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(room_id, player_num)
    );

    CREATE TABLE IF NOT EXISTS level_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
      level_num INTEGER NOT NULL,
      attempt_num INTEGER NOT NULL,
      p1_word TEXT,
      p2_word TEXT,
      is_match INTEGER NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS dsa_submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
      level_num INTEGER NOT NULL,
      problem_id TEXT NOT NULL,
      player_num INTEGER NOT NULL,
      code TEXT,
      language TEXT DEFAULT 'python',
      status TEXT NOT NULL,
      error_details TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS game_results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id INTEGER NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
      final_status TEXT NOT NULL,
      levels_cleared INTEGER NOT NULL,
      failed_levels_count INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE INDEX IF NOT EXISTS idx_rooms_code ON rooms(room_code);
    CREATE INDEX IF NOT EXISTS idx_players_session ON players(session_token);
    CREATE INDEX IF NOT EXISTS idx_attempts_room_level ON level_attempts(room_id, level_num);
  `);

  return db;
}

function getDb() {
  if (!db) {
    initDatabase();
  }
  return db;
}

// ----------------- Room Queries -----------------

function createRoomInDb(roomCode) {
  const d = getDb();
  const stmt = d.prepare(`
    INSERT INTO rooms (room_code, status, current_level, current_attempt, failed_levels, current_phase)
    VALUES (?, 'LOBBY', 1, 1, 0, 'LOBBY')
  `);
  const info = stmt.run(roomCode);
  return getRoomById(info.lastInsertRowid);
}

function getRoomByCode(roomCode) {
  const d = getDb();
  return d.prepare('SELECT * FROM rooms WHERE room_code = ?').get(roomCode);
}

function getRoomById(roomId) {
  const d = getDb();
  return d.prepare('SELECT * FROM rooms WHERE id = ?').get(roomId);
}

function updateRoomStateInDb(roomId, updates) {
  const d = getDb();
  const fields = [];
  const values = [];

  for (const [key, value] of Object.entries(updates)) {
    fields.push(`${key} = ?`);
    values.push(value);
  }

  fields.push('updated_at = CURRENT_TIMESTAMP');
  values.push(roomId);

  const sql = `UPDATE rooms SET ${fields.join(', ')} WHERE id = ?`;
  d.prepare(sql).run(...values);
  return getRoomById(roomId);
}

// ----------------- Player Queries -----------------

function addPlayerToDb({ roomId, playerNum, sessionToken, socketId, playerName }) {
  const d = getDb();
  const stmt = d.prepare(`
    INSERT INTO players (room_id, player_num, session_token, socket_id, player_name, is_connected)
    VALUES (?, ?, ?, ?, ?, 1)
  `);
  stmt.run(roomId, playerNum, sessionToken, socketId || null, playerName || `Player ${playerNum}`);
  return getPlayerBySession(sessionToken);
}

function getPlayerBySession(sessionToken) {
  const d = getDb();
  return d.prepare('SELECT * FROM players WHERE session_token = ?').get(sessionToken);
}

function getPlayersForRoom(roomId) {
  const d = getDb();
  return d.prepare('SELECT * FROM players WHERE room_id = ? ORDER BY player_num ASC').all(roomId);
}

function updatePlayerConnection(sessionToken, isConnected, socketId = null) {
  const d = getDb();
  const stmt = d.prepare(`
    UPDATE players
    SET is_connected = ?, socket_id = COALESCE(?, socket_id), last_active_at = CURRENT_TIMESTAMP
    WHERE session_token = ?
  `);
  stmt.run(isConnected ? 1 : 0, socketId, sessionToken);
  return getPlayerBySession(sessionToken);
}

// ----------------- Attempt Queries -----------------

function recordAttemptInDb({ roomId, levelNum, attemptNum, p1Word, p2Word, isMatch }) {
  const d = getDb();
  const stmt = d.prepare(`
    INSERT INTO level_attempts (room_id, level_num, attempt_num, p1_word, p2_word, is_match)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  stmt.run(roomId, levelNum, attemptNum, p1Word, p2Word, isMatch ? 1 : 0);
}

function getAttemptsForLevel(roomId, levelNum) {
  const d = getDb();
  return d.prepare(`
    SELECT * FROM level_attempts
    WHERE room_id = ? AND level_num = ?
    ORDER BY attempt_num ASC
  `).all(roomId, levelNum);
}

function getAllAttemptsForRoom(roomId) {
  const d = getDb();
  return d.prepare(`
    SELECT * FROM level_attempts
    WHERE room_id = ?
    ORDER BY level_num ASC, attempt_num ASC
  `).all(roomId);
}

// ----------------- DSA Submission Queries -----------------

function recordDsaSubmissionInDb({ roomId, levelNum, problemId, playerNum, code, language, status, errorDetails }) {
  const d = getDb();
  const stmt = d.prepare(`
    INSERT INTO dsa_submissions (room_id, level_num, problem_id, player_num, code, language, status, error_details)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(roomId, levelNum, problemId, playerNum, code, language || 'python', status, errorDetails || null);
}

// ----------------- Game Results Queries -----------------

function recordGameResultInDb({ roomId, finalStatus, levelsCleared, failedLevelsCount }) {
  const d = getDb();
  const stmt = d.prepare(`
    INSERT INTO game_results (room_id, final_status, levels_cleared, failed_levels_count)
    VALUES (?, ?, ?, ?)
  `);
  stmt.run(roomId, finalStatus, levelsCleared, failedLevelsCount);
}

module.exports = {
  initDatabase,
  getDb,
  createRoomInDb,
  getRoomByCode,
  getRoomById,
  updateRoomStateInDb,
  addPlayerToDb,
  getPlayerBySession,
  getPlayersForRoom,
  updatePlayerConnection,
  recordAttemptInDb,
  getAttemptsForLevel,
  getAllAttemptsForRoom,
  recordDsaSubmissionInDb,
  recordGameResultInDb
};
