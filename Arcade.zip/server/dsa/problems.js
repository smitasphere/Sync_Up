/**
 * DSA Problem Bank for Arcade Arena · Tech Verse 2026
 * 16 beginner-friendly problems tailored for 1st year CSE students.
 * Each problem includes samples and hidden test cases.
 */

const DSA_PROBLEMS = [
  {
    id: 'sum_of_array',
    title: 'Sum of an Array',
    topic: 'Arrays',
    difficulty: 'Easy',
    description: 'Given N integers, calculate their sum.',
    inputFormat: 'First line contains integer N.\nSecond line contains N space-separated integers.',
    outputFormat: 'Print the sum of the integers.',
    constraints: '1 <= N <= 1000\n-10000 <= Elements <= 10000',
    starterCode: `# Read input and calculate sum
import sys

def solve():
    lines = sys.stdin.read().split()
    if not lines:
        return
    n = int(lines[0])
    arr = [int(x) for x in lines[1:n+1]]
    print(sum(arr))

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: '5\n1 2 3 4 5', expected: '15' },
      { input: '4\n-10 20 -5 15', expected: '20' }
    ],
    hiddenTests: [
      { input: '1\n42', expected: '42' },
      { input: '6\n0 0 0 0 0 0', expected: '0' },
      { input: '5\n-5 -4 -3 -2 -1', expected: '-15' }
    ]
  },
  {
    id: 'reverse_string',
    title: 'Reverse a String',
    topic: 'Strings',
    difficulty: 'Easy',
    description: 'Given a string S, output the reversed string.',
    inputFormat: 'A single line containing the string S.',
    outputFormat: 'Print the reversed string.',
    constraints: '1 <= len(S) <= 500',
    starterCode: `import sys

def solve():
    s = sys.stdin.read().strip()
    print(s[::-1])

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: 'arcade', expected: 'edacra' },
      { input: 'techverse', expected: 'esrevhcet' }
    ],
    hiddenTests: [
      { input: 'a', expected: 'a' },
      { input: 'racecar', expected: 'racecar' },
      { input: 'Hello World', expected: 'dlroW olleH' }
    ]
  },
  {
    id: 'check_palindrome',
    title: 'Check Palindrome',
    topic: 'Strings',
    difficulty: 'Easy',
    description: 'Given a string S, check whether it is a palindrome (reads the same forward and backwards, case-sensitive). Print "YES" if it is, otherwise "NO".',
    inputFormat: 'A single line containing string S.',
    outputFormat: 'Print YES or NO.',
    constraints: '1 <= len(S) <= 1000',
    starterCode: `import sys

def solve():
    s = sys.stdin.read().strip()
    if s == s[::-1]:
        print("YES")
    else:
        print("NO")

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: 'radar', expected: 'YES' },
      { input: 'arena', expected: 'NO' }
    ],
    hiddenTests: [
      { input: 'madam', expected: 'YES' },
      { input: 'Madam', expected: 'NO' },
      { input: 'z', expected: 'YES' }
    ]
  },
  {
    id: 'find_maximum',
    title: 'Find Maximum Element',
    topic: 'Arrays',
    difficulty: 'Easy',
    description: 'Given N integers, find the maximum element among them.',
    inputFormat: 'First line contains integer N.\nSecond line contains N space-separated integers.',
    outputFormat: 'Print the maximum integer.',
    constraints: '1 <= N <= 1000\n-10000 <= Elements <= 10000',
    starterCode: `import sys

def solve():
    lines = sys.stdin.read().split()
    if not lines:
        return
    n = int(lines[0])
    arr = [int(x) for x in lines[1:n+1]]
    print(max(arr))

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: '5\n12 45 7 89 23', expected: '89' },
      { input: '3\n-5 -20 -1', expected: '-1' }
    ],
    hiddenTests: [
      { input: '1\n999', expected: '999' },
      { input: '4\n10 10 10 10', expected: '10' },
      { input: '6\n100 500 200 800 300 400', expected: '800' }
    ]
  },
  {
    id: 'count_vowels',
    title: 'Count Vowels',
    topic: 'Strings',
    difficulty: 'Easy',
    description: 'Given a string S, count how many vowels (a, e, i, o, u, case-insensitive) it contains.',
    inputFormat: 'A single line containing string S.',
    outputFormat: 'Print the number of vowels.',
    constraints: '1 <= len(S) <= 1000',
    starterCode: `import sys

def solve():
    s = sys.stdin.read().strip()
    vowels = set('aeiouAEIOU')
    count = sum(1 for ch in s if ch in vowels)
    print(count)

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: 'Technology', expected: '3' },
      { input: 'Arcade Arena', expected: '6' }
    ],
    hiddenTests: [
      { input: 'rhythm', expected: '0' },
      { input: 'AEIOU', expected: '5' },
      { input: 'Bennett University', expected: '6' }
    ]
  },
  {
    id: 'linear_search',
    title: 'Linear Search',
    topic: 'Linear search',
    difficulty: 'Easy',
    description: 'Given N integers and a target value K, find the 0-based index of the first occurrence of K. If K is not present, print -1.',
    inputFormat: 'First line contains two integers: N and K.\nSecond line contains N space-separated integers.',
    outputFormat: 'Print the 0-based index of K or -1.',
    constraints: '1 <= N <= 1000\n-10000 <= Elements, K <= 10000',
    starterCode: `import sys

def solve():
    lines = sys.stdin.read().split()
    if not lines:
        return
    n, k = int(lines[0]), int(lines[1])
    arr = [int(x) for x in lines[2:n+2]]
    try:
        print(arr.index(k))
    except ValueError:
        print(-1)

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: '5 7\n1 3 7 9 11', expected: '2' },
      { input: '4 5\n10 20 30 40', expected: '-1' }
    ],
    hiddenTests: [
      { input: '1 9\n9', expected: '0' },
      { input: '5 4\n4 4 4 4 4', expected: '0' },
      { input: '6 12\n2 4 6 8 10 12', expected: '5' }
    ]
  },
  {
    id: 'even_odd_count',
    title: 'Count Even and Odd Numbers',
    topic: 'Counting elements',
    difficulty: 'Easy',
    description: 'Given N integers, count how many are even and how many are odd.',
    inputFormat: 'First line: N.\nSecond line: N space-separated integers.',
    outputFormat: 'Print two space-separated integers: the count of even numbers followed by the count of odd numbers.',
    constraints: '1 <= N <= 1000',
    starterCode: `import sys

def solve():
    lines = sys.stdin.read().split()
    if not lines:
        return
    n = int(lines[0])
    arr = [int(x) for x in lines[1:n+1]]
    evens = sum(1 for x in arr if x % 2 == 0)
    odds = n - evens
    print(f"{evens} {odds}")

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: '5\n1 2 3 4 5', expected: '2 3' },
      { input: '4\n2 4 6 8', expected: '4 0' }
    ],
    hiddenTests: [
      { input: '3\n1 3 5', expected: '0 3' },
      { input: '1\n0', expected: '1 0' },
      { input: '6\n11 22 33 44 55 66', expected: '3 3' }
    ]
  },
  {
    id: 'check_prime',
    title: 'Check Prime Number',
    topic: 'Math / Logic',
    difficulty: 'Easy',
    description: 'Given a positive integer N, determine whether N is prime. Print "PRIME" if it is prime, otherwise print "NOT PRIME".',
    inputFormat: 'A single integer N.',
    outputFormat: 'Print PRIME or NOT PRIME.',
    constraints: '1 <= N <= 100000',
    starterCode: `import sys

def is_prime(n):
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

def solve():
    line = sys.stdin.read().strip()
    if not line:
        return
    n = int(line)
    print("PRIME" if is_prime(n) else "NOT PRIME")

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: '7', expected: 'PRIME' },
      { input: '10', expected: 'NOT PRIME' }
    ],
    hiddenTests: [
      { input: '1', expected: 'NOT PRIME' },
      { input: '2', expected: 'PRIME' },
      { input: '97', expected: 'PRIME' },
      { input: '49', expected: 'NOT PRIME' }
    ]
  },
  {
    id: 'fibonacci_number',
    title: 'N-th Fibonacci Number',
    topic: 'Basic Sequences',
    difficulty: 'Easy',
    description: 'Given an integer N, find the N-th Fibonacci number where Fib(0) = 0, Fib(1) = 1, Fib(2) = 1, and Fib(N) = Fib(N-1) + Fib(N-2).',
    inputFormat: 'A single integer N.',
    outputFormat: 'Print the N-th Fibonacci number.',
    constraints: '0 <= N <= 30',
    starterCode: `import sys

def solve():
    line = sys.stdin.read().strip()
    if not line:
        return
    n = int(line)
    if n == 0:
        print(0)
        return
    a, b = 0, 1
    for _ in range(n - 1):
        a, b = b, a + b
    print(b)

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: '6', expected: '8' },
      { input: '0', expected: '0' }
    ],
    hiddenTests: [
      { input: '1', expected: '1' },
      { input: '10', expected: '55' },
      { input: '20', expected: '6765' }
    ]
  },
  {
    id: 'second_largest',
    title: 'Second Largest Distinct Element',
    topic: 'Arrays',
    difficulty: 'Easy',
    description: 'Given N integers, find the second largest distinct element. If no second distinct element exists, print -1.',
    inputFormat: 'First line: N.\nSecond line: N space-separated integers.',
    outputFormat: 'Print the second largest distinct integer or -1.',
    constraints: '1 <= N <= 1000',
    starterCode: `import sys

def solve():
    lines = sys.stdin.read().split()
    if not lines:
        return
    n = int(lines[0])
    arr = [int(x) for x in lines[1:n+1]]
    distinct = sorted(list(set(arr)), reverse=True)
    if len(distinct) < 2:
        print(-1)
    else:
        print(distinct[1])

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: '5\n10 20 30 40 50', expected: '40' },
      { input: '4\n5 5 5 5', expected: '-1' }
    ],
    hiddenTests: [
      { input: '3\n10 5 10', expected: '5' },
      { input: '2\n-1 -2', expected: '-2' },
      { input: '6\n1 9 4 9 8 3', expected: '8' }
    ]
  },
  {
    id: 'remove_duplicates_count',
    title: 'Count Unique Sorted Elements',
    topic: 'Arrays',
    difficulty: 'Easy',
    description: 'Given a non-decreasing sorted array of N integers, count the number of unique elements.',
    inputFormat: 'First line: N.\nSecond line: N sorted integers.',
    outputFormat: 'Print the count of unique elements.',
    constraints: '1 <= N <= 1000',
    starterCode: `import sys

def solve():
    lines = sys.stdin.read().split()
    if not lines:
        return
    n = int(lines[0])
    arr = [int(x) for x in lines[1:n+1]]
    print(len(set(arr)))

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: '6\n1 1 2 2 3 4', expected: '4' },
      { input: '4\n7 7 7 7', expected: '1' }
    ],
    hiddenTests: [
      { input: '1\n10', expected: '1' },
      { input: '5\n-3 -3 0 1 1', expected: '3' },
      { input: '5\n1 2 3 4 5', expected: '5' }
    ]
  },
  {
    id: 'char_frequency',
    title: 'Character Frequency Count',
    topic: 'Frequency counting',
    difficulty: 'Easy',
    description: 'Given a string S and a character C, count how many times C appears in S (case-sensitive).',
    inputFormat: 'First line contains string S.\nSecond line contains character C.',
    outputFormat: 'Print the frequency count.',
    constraints: '1 <= len(S) <= 1000',
    starterCode: `import sys

def solve():
    lines = sys.stdin.read().splitlines()
    if not lines:
        return
    s = lines[0]
    c = lines[1].strip() if len(lines) > 1 else ''
    print(s.count(c))

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: 'engineering\ne', expected: '3' },
      { input: 'arcade\nz', expected: '0' }
    ],
    hiddenTests: [
      { input: 'TechVerse 2026\ne', expected: '3' },
      { input: 'aaaaa\na', expected: '5' },
      { input: 'Case Sensitive\nC', expected: '1' }
    ]
  },
  {
    id: 'factorial_number',
    title: 'Factorial of a Number',
    topic: 'Math / Logic',
    difficulty: 'Easy',
    description: 'Given an integer N, calculate its factorial N! (0! = 1).',
    inputFormat: 'A single integer N.',
    outputFormat: 'Print N!.',
    constraints: '0 <= N <= 15',
    starterCode: `import sys
import math

def solve():
    line = sys.stdin.read().strip()
    if not line:
        return
    n = int(line)
    print(math.factorial(n))

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: '5', expected: '120' },
      { input: '0', expected: '1' }
    ],
    hiddenTests: [
      { input: '1', expected: '1' },
      { input: '7', expected: '5040' },
      { input: '10', expected: '3628800' }
    ]
  },
  {
    id: 'min_and_max',
    title: 'Minimum and Maximum in Array',
    topic: 'Finding maximum and minimum',
    difficulty: 'Easy',
    description: 'Given N integers, find both the minimum and maximum element.',
    inputFormat: 'First line: N.\nSecond line: N space-separated integers.',
    outputFormat: 'Print minimum followed by maximum, separated by a single space.',
    constraints: '1 <= N <= 1000',
    starterCode: `import sys

def solve():
    lines = sys.stdin.read().split()
    if not lines:
        return
    n = int(lines[0])
    arr = [int(x) for x in lines[1:n+1]]
    print(f"{min(arr)} {max(arr)}")

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: '6\n3 2 1 56 1000 167', expected: '1 1000' },
      { input: '3\n-10 -5 -20', expected: '-20 -5' }
    ],
    hiddenTests: [
      { input: '1\n50', expected: '50 50' },
      { input: '4\n0 0 0 0', expected: '0 0' },
      { input: '5\n-5 5 -10 10 0', expected: '-10 10' }
    ]
  },
  {
    id: 'array_average',
    title: 'Average of an Array',
    topic: 'Arrays',
    difficulty: 'Easy',
    description: 'Given N integers, calculate their floor average (integer division of sum by N).',
    inputFormat: 'First line: N.\nSecond line: N space-separated integers.',
    outputFormat: 'Print the floor average (integer value).',
    constraints: '1 <= N <= 1000',
    starterCode: `import sys

def solve():
    lines = sys.stdin.read().split()
    if not lines:
        return
    n = int(lines[0])
    arr = [int(x) for x in lines[1:n+1]]
    print(sum(arr) // n)

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: '5\n1 2 3 4 5', expected: '3' },
      { input: '4\n10 20 30 41', expected: '25' }
    ],
    hiddenTests: [
      { input: '1\n100', expected: '100' },
      { input: '3\n-3 -6 -9', expected: '-6' },
      { input: '5\n10 10 10 10 10', expected: '10' }
    ]
  },
  {
    id: 'count_negative_numbers',
    title: 'Count Negative Numbers',
    topic: 'Counting elements',
    difficulty: 'Easy',
    description: 'Given N integers, count how many of them are strictly less than 0.',
    inputFormat: 'First line: N.\nSecond line: N space-separated integers.',
    outputFormat: 'Print the count of negative integers.',
    constraints: '1 <= N <= 1000',
    starterCode: `import sys

def solve():
    lines = sys.stdin.read().split()
    if not lines:
        return
    n = int(lines[0])
    arr = [int(x) for x in lines[1:n+1]]
    count = sum(1 for x in arr if x < 0)
    print(count)

if __name__ == '__main__':
    solve()
`,
    sampleTests: [
      { input: '5\n-1 2 -3 4 -5', expected: '3' },
      { input: '4\n1 2 3 4', expected: '0' }
    ],
    hiddenTests: [
      { input: '3\n-10 -20 -30', expected: '3' },
      { input: '1\n0', expected: '0' },
      { input: '6\n0 -1 0 -2 0 -3', expected: '3' }
    ]
  }
];

/**
 * Returns a problem by its ID.
 */
function getProblemById(id) {
  return DSA_PROBLEMS.find(p => p.id === id) || null;
}

/**
 * Picks a problem for a room, optionally avoiding already assigned problem IDs.
 */
function pickProblemForRoom(assignedIds = []) {
  const available = DSA_PROBLEMS.filter(p => !assignedIds.includes(p.id));
  const pool = available.length > 0 ? available : DSA_PROBLEMS;
  const index = Math.floor(Math.random() * pool.length);
  return pool[index];
}

/**
 * Returns sanitized problem data for client display (omits hidden test cases).
 */
function sanitizeProblemForClient(problem) {
  if (!problem) return null;
  return {
    id: problem.id,
    title: problem.title,
    topic: problem.topic,
    difficulty: problem.difficulty,
    description: problem.description,
    inputFormat: problem.inputFormat,
    outputFormat: problem.outputFormat,
    constraints: problem.constraints,
    starterCode: problem.starterCode,
    sampleTests: problem.sampleTests
  };
}

module.exports = {
  DSA_PROBLEMS,
  getProblemById,
  pickProblemForRoom,
  sanitizeProblemForClient
};
