/**
 * DSA Solution Evaluator for Arcade Arena · Tech Verse 2026
 * Evaluates Python 3 solutions using isolated child_process execution with strict timeouts.
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { getProblemById } = require('./problems');

const EXECUTION_TIMEOUT_MS = 2500;
const MAX_OUTPUT_BYTES = 64 * 1024; // 64 KB
const MAX_CODE_LENGTH = 16384; // 16 KB

/**
 * Normalizes output string for comparison:
 * - replaces Windows CRLF with LF
 * - trims trailing whitespace from each line
 * - trims trailing whitespace from whole text
 */
function normalizeOutput(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map(line => line.trimEnd())
    .join('\n')
    .trim();
}

/**
 * Runs a Python 3 script with given stdin input in a separate process.
 */
function runPythonCode(code, stdinInput) {
  return new Promise((resolve) => {
    // Write temporary code file to OS temp dir
    const tmpDir = os.tmpdir();
    const tmpFile = path.join(tmpDir, `arcade_sub_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.py`);

    try {
      fs.writeFileSync(tmpFile, code, 'utf8');
    } catch (err) {
      return resolve({
        status: 'INTERNAL_ERROR',
        message: 'Failed to write submission file',
        output: '',
        stderr: err.message
      });
    }

    const cleanup = () => {
      try {
        if (fs.existsSync(tmpFile)) fs.unlinkSync(tmpFile);
      } catch (e) {}
    };

    // Execute Python with isolated flags (-I: isolate from user site/env, -B: don't write .pyc)
    const proc = spawn('python3', ['-I', '-B', tmpFile]);

    let stdout = '';
    let stderr = '';
    let timedOut = false;
    let killed = false;

    const timer = setTimeout(() => {
      timedOut = true;
      killed = true;
      try {
        proc.kill('SIGKILL');
      } catch (e) {}
    }, EXECUTION_TIMEOUT_MS);

    proc.stdout.on('data', (data) => {
      if (stdout.length < MAX_OUTPUT_BYTES) {
        stdout += data.toString();
      }
    });

    proc.stderr.on('data', (data) => {
      if (stderr.length < MAX_OUTPUT_BYTES) {
        stderr += data.toString();
      }
    });

    proc.on('error', (err) => {
      clearTimeout(timer);
      cleanup();
      resolve({
        status: 'RUNTIME_ERROR',
        message: 'Process execution error: ' + err.message,
        output: '',
        stderr: err.message
      });
    });

    proc.on('close', (code, signal) => {
      clearTimeout(timer);
      cleanup();

      if (timedOut) {
        return resolve({
          status: 'TIME_LIMIT_EXCEEDED',
          message: `Time limit exceeded (${EXECUTION_TIMEOUT_MS}ms)`,
          output: stdout,
          stderr: 'Time Limit Exceeded'
        });
      }

      if (code !== 0) {
        // Clean python traceback to not expose machine path
        const cleanedStderr = (stderr || 'Execution failed')
          .replace(new RegExp(tmpFile, 'g'), 'solution.py')
          .slice(0, 1000);

        const isSyntax = /SyntaxError|IndentationError/.test(cleanedStderr);
        return resolve({
          status: isSyntax ? 'COMPILATION_ERROR' : 'RUNTIME_ERROR',
          message: cleanedStderr,
          output: stdout,
          stderr: cleanedStderr
        });
      }

      resolve({
        status: 'OK',
        output: stdout,
        stderr: ''
      });
    });

    // Provide stdin and close pipe
    try {
      proc.stdin.write(stdinInput || '');
      proc.stdin.end();
    } catch (e) {
      // pipe closed early
    }
  });
}

/**
 * Evaluates a submitted solution against sample and hidden test cases.
 */
async function evaluateSubmission({ problemId, code, language = 'python' }) {
  if (!code || typeof code !== 'string' || !code.trim()) {
    return {
      success: false,
      status: 'EMPTY_CODE',
      message: 'Code submission cannot be empty.'
    };
  }

  if (code.length > MAX_CODE_LENGTH) {
    return {
      success: false,
      status: 'CODE_TOO_LARGE',
      message: `Code exceeds maximum allowed size of ${MAX_CODE_LENGTH / 1024} KB.`
    };
  }

  if (language !== 'python' && language !== 'python3') {
    return {
      success: false,
      status: 'UNSUPPORTED_LANGUAGE',
      message: `Language '${language}' is not supported yet. Please submit in Python 3.`
    };
  }

  const problem = getProblemById(problemId);
  if (!problem) {
    return {
      success: false,
      status: 'PROBLEM_NOT_FOUND',
      message: `Problem ID '${problemId}' not found.`
    };
  }

  // Basic security check: disallow os.system, subprocess, socket, pty, sh, exec, eval
  const dangerousPatterns = [
    /\bos\.(system|popen|spawn|exec|remove|unlink|rmdir)\b/,
    /\bsubprocess\b/,
    /\bshutil\b/,
    /\bsocket\b/,
    /\bpty\b/,
    /__import__\s*\(\s*['"](os|subprocess|socket|pty|shutil)['"]\s*\)/
  ];

  for (const pattern of dangerousPatterns) {
    if (pattern.test(code)) {
      return {
        success: false,
        status: 'SECURITY_VIOLATION',
        message: 'Security violation: Restricted modules or system calls are not permitted.'
      };
    }
  }

  // 1. Run sample test cases
  const sampleResults = [];
  for (let i = 0; i < problem.sampleTests.length; i++) {
    const test = problem.sampleTests[i];
    const execRes = await runPythonCode(code, test.input);

    if (execRes.status !== 'OK') {
      return {
        success: false,
        status: execRes.status,
        message: `Sample Test Case ${i + 1} Failed: ${execRes.message}`,
        failedCase: {
          testNumber: i + 1,
          isSample: true,
          input: test.input,
          expected: test.expected,
          actual: normalizeOutput(execRes.output),
          error: execRes.stderr
        }
      };
    }

    const actual = normalizeOutput(execRes.output);
    const expected = normalizeOutput(test.expected);

    if (actual !== expected) {
      return {
        success: false,
        status: 'WRONG_ANSWER',
        message: `Sample Test Case ${i + 1} Failed. Output did not match expected answer.`,
        failedCase: {
          testNumber: i + 1,
          isSample: true,
          input: test.input,
          expected: test.expected,
          actual
        }
      };
    }

    sampleResults.push({ testNumber: i + 1, passed: true });
  }

  // 2. Run hidden test cases (Do NOT reveal inputs or expected values to client)
  for (let i = 0; i < problem.hiddenTests.length; i++) {
    const test = problem.hiddenTests[i];
    const execRes = await runPythonCode(code, test.input);

    if (execRes.status !== 'OK') {
      return {
        success: false,
        status: execRes.status,
        message: `Hidden Test Case ${i + 1} Failed with ${execRes.status}.`,
        failedCase: {
          testNumber: problem.sampleTests.length + i + 1,
          isSample: false,
          error: execRes.message
        }
      };
    }

    const actual = normalizeOutput(execRes.output);
    const expected = normalizeOutput(test.expected);

    if (actual !== expected) {
      return {
        success: false,
        status: 'WRONG_ANSWER',
        message: `Hidden Test Case ${i + 1} Failed. Output did not match.`,
        failedCase: {
          testNumber: problem.sampleTests.length + i + 1,
          isSample: false
        }
      };
    }
  }

  return {
    success: true,
    status: 'ACCEPTED',
    message: 'All test cases passed! Solution Accepted.',
    totalCasesPassed: problem.sampleTests.length + problem.hiddenTests.length
  };
}

module.exports = {
  evaluateSubmission,
  runPythonCode,
  normalizeOutput
};
