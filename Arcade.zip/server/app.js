/**
 * Express Application for Arcade Arena · Tech Verse 2026
 * Configures static assets, CORS, rate limits, and REST endpoints.
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const os = require('os');
const { apiLimiter, roomCreateLimiter } = require('./middleware/rateLimit');
const { sanitizeInput, validateRoomCode } = require('./middleware/validation');
const roomManager = require('./roomManager');
const gameManager = require('./gameManager');
const { getProblemById, sanitizeProblemForClient } = require('./dsa/problems');

const app = express();

app.use(cors());
app.use(express.json({ limit: '64kb' }));
app.use(express.urlencoded({ extended: true }));

// Serve static frontend files from /public
app.use(express.static(path.join(__dirname, '..', 'public')));

// Helper to determine best join base URL (Deploy URL or LAN IP for mobile scan)
function getBaseUrl(req) {
  if (process.env.PUBLIC_URL) {
    return process.env.PUBLIC_URL.replace(/\/+$/, '');
  }
  if (process.env.HOST_URL) {
    return process.env.HOST_URL.replace(/\/+$/, '');
  }

  // Detect local LAN IPv4 address for multi-device local testing
  const interfaces = os.networkInterfaces();
  let lanIp = 'localhost';

  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        lanIp = iface.address;
        break;
      }
    }
  }

  const port = process.env.PORT || 3000;
  return `http://${lanIp}:${port}`;
}

// ----------------- REST Endpoints -----------------

// Server info for QR codes and client network configuration
app.get('/api/server-info', (req, res) => {
  const baseUrl = getBaseUrl(req);
  res.json({
    status: 'ok',
    baseUrl,
    nodeEnv: process.env.NODE_ENV || 'development'
  });
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    service: 'Arcade Arena Tech Verse Server'
  });
});

// Create room
app.post('/api/rooms', roomCreateLimiter, (req, res) => {
  try {
    const rawName = req.body.playerName || 'Player 1';
    const playerName = sanitizeInput(rawName, 20);
    const { room, player } = roomManager.createRoom({ playerName });

    const baseUrl = getBaseUrl(req);
    const joinUrl = `${baseUrl}/#${room.code}`;

    res.status(201).json({
      success: true,
      roomId: room.id,
      roomCode: room.code,
      sessionToken: player.sessionToken,
      playerNum: 1,
      playerName: player.name,
      joinUrl,
      gameState: gameManager.getSafeGameState(room)
    });
  } catch (err) {
    console.error('Error creating room:', err);
    res.status(500).json({ error: 'SERVER_ERROR', message: 'Failed to create room.' });
  }
});

// Get public room information
app.get('/api/rooms/:roomId', apiLimiter, validateRoomCode, (req, res) => {
  const room = roomManager.getRoom(req.params.roomId);
  if (!room) {
    return res.status(404).json({ error: 'ROOM_NOT_FOUND', message: 'Room not found.' });
  }

  const playerCount = (room.players[1] ? 1 : 0) + (room.players[2] ? 1 : 0);
  const isFull = playerCount >= 2;

  res.json({
    roomCode: room.code,
    status: room.status,
    playerCount,
    isFull,
    currentLevel: room.currentLevel,
    failedLevels: room.failedLevels
  });
});

// Reconnect check
app.post('/api/rooms/:roomId/reconnect', apiLimiter, validateRoomCode, (req, res) => {
  const { sessionToken } = req.body;
  if (!sessionToken || typeof sessionToken !== 'string') {
    return res.status(400).json({ error: 'MISSING_TOKEN', message: 'Session token is required.' });
  }

  const result = roomManager.reconnectPlayer(req.params.roomId, sessionToken);
  if (!result.success) {
    return res.status(401).json(result);
  }

  res.json({
    success: true,
    roomCode: result.room.code,
    playerNum: result.player.playerNum,
    sessionToken: result.player.sessionToken,
    gameState: gameManager.getSafeGameState(result.room)
  });
});

// Retrieve DSA problem statement
app.get('/api/problems/:problemId', apiLimiter, (req, res) => {
  const prob = getProblemById(req.params.problemId);
  if (!prob) {
    return res.status(404).json({ error: 'PROBLEM_NOT_FOUND', message: 'Problem not found.' });
  }
  res.json(sanitizeProblemForClient(prob));
});

module.exports = { app, getBaseUrl };
