/**
 * Authoritative Game Manager for Arcade Arena · Tech Verse 2026
 * Controls all game state transitions, secret word submissions, 3-attempt resets,
 * DSA challenge assignments, and the 3-failed-level elimination rule.
 */

const {
  MAX_LEVELS,
  MAX_ATTEMPTS_PER_LEVEL,
  MAX_FAILED_LEVELS,
  PHASES,
  wordsMatch,
  validateWordSubmission,
  getZoneForLevel
} = require('./gameRules');
const { pickProblemForRoom, sanitizeProblemForClient, getProblemById } = require('./dsa/problems');
const { evaluateSubmission } = require('./dsa/evaluator');
const db = require('./database');

/**
 * Returns safe sanitized game state suitable for broadcasting to clients.
 */
function getSafeGameState(room) {
  const zone = getZoneForLevel(room.currentLevel);
  const attempts = db.getAttemptsForLevel(room.id, room.currentLevel);

  let dsaProblem = null;
  if (room.phase === PHASES.DSA_CHALLENGE && room.assignedDsaProblemId) {
    const rawProb = getProblemById(room.assignedDsaProblemId);
    dsaProblem = sanitizeProblemForClient(rawProb);
  }

  return {
    roomId: room.id,
    roomCode: room.code,
    status: room.status,
    phase: room.phase,
    currentLevel: room.currentLevel,
    maxLevels: MAX_LEVELS,
    currentAttempt: room.currentAttempt,
    maxAttempts: MAX_ATTEMPTS_PER_LEVEL,
    failedLevels: room.failedLevels,
    maxFailedLevels: MAX_FAILED_LEVELS,
    zone,
    submissionsLocked: {
      1: !!room.currentSubmissions[1],
      2: !!room.currentSubmissions[2]
    },
    currentLevelAttempts: attempts.map(a => ({
      attemptNum: a.attempt_num,
      p1Word: a.p1_word,
      p2Word: a.p2_word,
      isMatch: !!a.is_match
    })),
    assignedDsaProblem: dsaProblem,
    winner: room.winner,
    eliminationReason: room.eliminationReason,
    players: {
      1: room.players[1] ? { playerNum: 1, name: room.players[1].name, connected: !!room.players[1].connected } : null,
      2: room.players[2] ? { playerNum: 2, name: room.players[2].name, connected: !!room.players[2].connected } : null
    }
  };
}

/**
 * Starts the game if both players are present.
 */
function startGame(room, requestingSessionToken) {
  if (!room.players[1] || room.players[1].sessionToken !== requestingSessionToken) {
    return { success: false, error: 'ONLY_HOST_CAN_START', message: 'Only Player 1 (Host) can start the game.' };
  }

  if (!room.players[2]) {
    return { success: false, error: 'WAITING_FOR_PLAYER_2', message: 'Cannot start game without Player 2.' };
  }

  if (room.status === 'PLAYING') {
    return { success: false, error: 'ALREADY_STARTED', message: 'Game is already in progress.' };
  }

  room.status = 'PLAYING';
  room.currentLevel = 1;
  room.currentAttempt = 1;
  room.failedLevels = 0;
  room.phase = PHASES.GUESSING;
  room.currentSubmissions = { 1: null, 2: null };
  room.updatedAt = Date.now();

  db.updateRoomStateInDb(room.id, {
    status: 'PLAYING',
    current_level: 1,
    current_attempt: 1,
    failed_levels: 0,
    current_phase: PHASES.GUESSING
  });

  return { success: true, gameState: getSafeGameState(room) };
}

/**
 * Handles secret word submission from a player.
 */
function submitWord(room, sessionToken, word) {
  if (room.status !== 'PLAYING') {
    return { success: false, error: 'GAME_NOT_ACTIVE', message: 'Game is not currently active.' };
  }

  if (room.phase !== PHASES.GUESSING) {
    return { success: false, error: 'NOT_IN_GUESSING_PHASE', message: `Cannot submit word in phase ${room.phase}.` };
  }

  let playerNum = null;
  if (room.players[1] && room.players[1].sessionToken === sessionToken) playerNum = 1;
  else if (room.players[2] && room.players[2].sessionToken === sessionToken) playerNum = 2;

  if (!playerNum) {
    return { success: false, error: 'UNAUTHORIZED', message: 'Player session not recognized in this room.' };
  }

  if (room.currentSubmissions[playerNum] !== null) {
    return { success: false, error: 'ALREADY_SUBMITTED', message: 'You have already locked in your word for this attempt.' };
  }

  const validation = validateWordSubmission(word);
  if (!validation.valid) {
    return { success: false, error: 'INVALID_WORD', message: validation.error };
  }

  // Store secret answer privately
  room.currentSubmissions[playerNum] = validation.cleaned;
  room.updatedAt = Date.now();

  const otherPlayerNum = playerNum === 1 ? 2 : 1;
  const bothSubmitted = room.currentSubmissions[1] !== null && room.currentSubmissions[2] !== null;

  if (!bothSubmitted) {
    // Only one player has submitted so far
    return {
      success: true,
      bothSubmitted: false,
      playerNum,
      otherPlayerNum,
      gameState: getSafeGameState(room)
    };
  }

  // Both have submitted! Evaluate attempt
  const w1 = room.currentSubmissions[1];
  const w2 = room.currentSubmissions[2];
  const isMatch = wordsMatch(w1, w2);

  // Record attempt in database
  db.recordAttemptInDb({
    roomId: room.id,
    levelNum: room.currentLevel,
    attemptNum: room.currentAttempt,
    p1Word: w1,
    p2Word: w2,
    isMatch
  });

  // Reset submissions for next attempt
  room.currentSubmissions = { 1: null, 2: null };

  if (isMatch) {
    // SUCCESSFUL MATCH!
    const clearedLevel = room.currentLevel;

    if (clearedLevel >= MAX_LEVELS) {
      // VICTORY! Cleared level 9
      room.status = 'WON';
      room.phase = PHASES.GAME_COMPLETED;
      room.winner = 1;

      db.updateRoomStateInDb(room.id, {
        status: 'WON',
        current_phase: PHASES.GAME_COMPLETED,
        winner: 1
      });

      db.recordGameResultInDb({
        roomId: room.id,
        finalStatus: 'WON',
        levelsCleared: MAX_LEVELS,
        failedLevelsCount: room.failedLevels
      });

      return {
        success: true,
        bothSubmitted: true,
        isMatch: true,
        isGameWon: true,
        clearedLevel,
        p1Word: w1,
        p2Word: w2,
        attemptNum: room.currentAttempt,
        gameState: getSafeGameState(room)
      };
    }

    // Advance to next level!
    room.currentLevel += 1;
    room.currentAttempt = 1; // Resets attempts to 1 for the new level
    room.phase = PHASES.LEVEL_CLEARED;

    db.updateRoomStateInDb(room.id, {
      current_level: room.currentLevel,
      current_attempt: 1,
      current_phase: PHASES.LEVEL_CLEARED
    });

    return {
      success: true,
      bothSubmitted: true,
      isMatch: true,
      isGameWon: false,
      clearedLevel,
      nextLevel: room.currentLevel,
      p1Word: w1,
      p2Word: w2,
      attemptNum: room.currentAttempt,
      gameState: getSafeGameState(room)
    };
  }

  // MISMATCH!
  if (room.currentAttempt < MAX_ATTEMPTS_PER_LEVEL) {
    // Attempts remaining for this level!
    const failedAttempt = room.currentAttempt;
    room.currentAttempt += 1;
    room.phase = PHASES.ATTEMPT_RESULT;

    db.updateRoomStateInDb(room.id, {
      current_attempt: room.currentAttempt,
      current_phase: PHASES.ATTEMPT_RESULT
    });

    return {
      success: true,
      bothSubmitted: true,
      isMatch: false,
      attemptsExhausted: false,
      failedAttempt,
      remainingAttempts: MAX_ATTEMPTS_PER_LEVEL - failedAttempt,
      nextAttemptNum: room.currentAttempt,
      p1Word: w1,
      p2Word: w2,
      gameState: getSafeGameState(room)
    };
  }

  // 3 ATTEMPTS EXHAUSTED WITHOUT MATCHING!
  room.failedLevels += 1;

  if (room.failedLevels >= MAX_FAILED_LEVELS) {
    // IMMEDIATE ELIMINATION! 3 failed levels
    room.status = 'ELIMINATED';
    room.phase = PHASES.ELIMINATED;
    room.eliminationReason = `Team failed 3 different levels (Level ${room.currentLevel} exhausted all 3 attempts).`;

    db.updateRoomStateInDb(room.id, {
      status: 'ELIMINATED',
      current_phase: PHASES.ELIMINATED,
      failed_levels: room.failedLevels,
      elimination_reason: room.eliminationReason
    });

    db.recordGameResultInDb({
      roomId: room.id,
      finalStatus: 'ELIMINATED',
      levelsCleared: room.currentLevel - 1,
      failedLevelsCount: room.failedLevels
    });

    return {
      success: true,
      bothSubmitted: true,
      isMatch: false,
      attemptsExhausted: true,
      isEliminated: true,
      p1Word: w1,
      p2Word: w2,
      failedLevels: room.failedLevels,
      eliminationReason: room.eliminationReason,
      gameState: getSafeGameState(room)
    };
  }

  // Fewer than 3 failed levels -> TRANSITION TO DSA CHALLENGE!
  const assignedProb = pickProblemForRoom(room.assignedDsaHistory || []);
  room.assignedDsaProblemId = assignedProb.id;
  room.assignedDsaHistory = room.assignedDsaHistory || [];
  room.assignedDsaHistory.push(assignedProb.id);
  room.phase = PHASES.DSA_CHALLENGE;

  db.updateRoomStateInDb(room.id, {
    failed_levels: room.failedLevels,
    current_phase: PHASES.DSA_CHALLENGE,
    assigned_dsa_problem_id: assignedProb.id
  });

  return {
    success: true,
    bothSubmitted: true,
    isMatch: false,
    attemptsExhausted: true,
    isEliminated: false,
    p1Word: w1,
    p2Word: w2,
    failedLevels: room.failedLevels,
    dsaProblem: sanitizeProblemForClient(assignedProb),
    gameState: getSafeGameState(room)
  };
}

/**
 * Transitions from ATTEMPT_RESULT back to GUESSING for the next attempt.
 */
function proceedToNextAttempt(room) {
  if (room.phase !== PHASES.ATTEMPT_RESULT) {
    return { success: false, error: 'INVALID_PHASE', message: 'Not waiting for next attempt.' };
  }
  room.phase = PHASES.GUESSING;
  db.updateRoomStateInDb(room.id, { current_phase: PHASES.GUESSING });
  return { success: true, gameState: getSafeGameState(room) };
}

/**
 * Transitions from LEVEL_CLEARED to GUESSING for the new level.
 */
function proceedToNextLevel(room) {
  if (room.phase !== PHASES.LEVEL_CLEARED) {
    return { success: false, error: 'INVALID_PHASE', message: 'Not waiting for next level.' };
  }
  room.phase = PHASES.GUESSING;
  db.updateRoomStateInDb(room.id, { current_phase: PHASES.GUESSING });
  return { success: true, gameState: getSafeGameState(room) };
}

/**
 * Evaluates DSA code solution from either player.
 */
async function submitDsaSolution(room, sessionToken, problemId, code, language = 'python') {
  if (room.status !== 'PLAYING' || room.phase !== PHASES.DSA_CHALLENGE) {
    return { success: false, error: 'NOT_IN_DSA_PHASE', message: 'Room is not currently in a DSA challenge phase.' };
  }

  let playerNum = null;
  if (room.players[1] && room.players[1].sessionToken === sessionToken) playerNum = 1;
  else if (room.players[2] && room.players[2].sessionToken === sessionToken) playerNum = 2;

  if (!playerNum) {
    return { success: false, error: 'UNAUTHORIZED', message: 'Player session not recognized in this room.' };
  }

  if (room.assignedDsaProblemId !== problemId) {
    return { success: false, error: 'WRONG_PROBLEM', message: 'Submitted problem ID does not match assigned challenge.' };
  }

  // Run evaluation
  const result = await evaluateSubmission({ problemId, code, language });

  // Record submission in database
  db.recordDsaSubmissionInDb({
    roomId: room.id,
    levelNum: room.currentLevel,
    problemId,
    playerNum,
    code,
    language,
    status: result.status,
    errorDetails: result.message
  });

  if (!result.success) {
    // Solution failed; allow players to try again
    return {
      success: false,
      status: result.status,
      message: result.message,
      playerNum,
      failedCase: result.failedCase || null,
      gameState: getSafeGameState(room)
    };
  }

  // DSA PASSED!
  const clearedLevel = room.currentLevel;

  if (clearedLevel >= MAX_LEVELS) {
    // VICTORY!
    room.status = 'WON';
    room.phase = PHASES.GAME_COMPLETED;
    room.winner = 1;

    db.updateRoomStateInDb(room.id, {
      status: 'WON',
      current_phase: PHASES.GAME_COMPLETED,
      winner: 1
    });

    db.recordGameResultInDb({
      roomId: room.id,
      finalStatus: 'WON',
      levelsCleared: MAX_LEVELS,
      failedLevelsCount: room.failedLevels
    });

    return {
      success: true,
      isGameWon: true,
      clearedLevel,
      playerNum,
      message: result.message,
      gameState: getSafeGameState(room)
    };
  }

  // Advance to next level
  room.currentLevel += 1;
  room.currentAttempt = 1; // Resets attempts to 1 for the new level
  room.phase = PHASES.LEVEL_CLEARED;
  room.assignedDsaProblemId = null;

  db.updateRoomStateInDb(room.id, {
    current_level: room.currentLevel,
    current_attempt: 1,
    current_phase: PHASES.LEVEL_CLEARED,
    assigned_dsa_problem_id: null
  });

  return {
    success: true,
    isGameWon: false,
    clearedLevel,
    nextLevel: room.currentLevel,
    playerNum,
    message: result.message,
    gameState: getSafeGameState(room)
  };
}

module.exports = {
  getSafeGameState,
  startGame,
  submitWord,
  proceedToNextAttempt,
  proceedToNextLevel,
  submitDsaSolution
};
