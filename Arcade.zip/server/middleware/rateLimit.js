/**
 * Rate Limiting Middleware for Arcade Arena · Tech Verse 2026
 */

const rateLimit = require('express-rate-limit');

// General API rate limiter: 120 requests per minute
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'TOO_MANY_REQUESTS', message: 'Too many requests, please try again later.' }
});

// Room creation rate limiter: 20 rooms per 15 minutes per IP
const roomCreateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'TOO_MANY_ROOMS', message: 'Room creation rate limit exceeded. Please wait a moment.' }
});

module.exports = {
  apiLimiter,
  roomCreateLimiter
};
