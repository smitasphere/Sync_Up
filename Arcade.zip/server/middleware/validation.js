/**
 * Validation Middleware and Utilities for Arcade Arena · Tech Verse 2026
 */

function sanitizeInput(text, maxLength = 32) {
  if (typeof text !== 'string') return '';
  return text
    .replace(/[&<>"'/]/g, (c) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
      '/': '&#x2F;'
    }[c] || c))
    .trim()
    .slice(0, maxLength);
}

function validateRoomCode(req, res, next) {
  const code = req.params.roomId || req.body.roomId;
  if (!code || typeof code !== 'string' || !/^TV[0-9]{4}$/i.test(code.trim())) {
    return res.status(400).json({ error: 'INVALID_ROOM_CODE', message: 'Room code must be in format TV followed by 4 digits (e.g. TV1234)' });
  }
  next();
}

module.exports = {
  sanitizeInput,
  validateRoomCode
};
