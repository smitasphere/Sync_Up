/**
 * Unit Tests for DSA Problems and Evaluator
 */

const { expect } = require('chai');
const { DSA_PROBLEMS, getProblemById } = require('../server/dsa/problems');
const { evaluateSubmission, normalizeOutput } = require('../server/dsa/evaluator');

describe('DSA Problems & Execution Evaluator', function () {
  this.timeout(10000);

  it('should contain at least 15 beginner DSA problems', () => {
    expect(DSA_PROBLEMS.length).to.be.at.least(15);
    DSA_PROBLEMS.forEach(p => {
      expect(p.id).to.be.a('string');
      expect(p.title).to.be.a('string');
      expect(p.description).to.be.a('string');
      expect(p.sampleTests).to.be.an('array').with.length.of.at.least(2);
      expect(p.hiddenTests).to.be.an('array').with.length.of.at.least(1);
      expect(p.starterCode).to.be.a('string');
    });
  });

  it('TEST 12: A correct DSA solution passes validation and returns ACCEPTED', async () => {
    const sumCode = `import sys
def solve():
    lines = sys.stdin.read().split()
    if not lines:
        return
    n = int(lines[0])
    arr = [int(x) for x in lines[1:n+1]]
    print(sum(arr))
if __name__ == '__main__':
    solve()
`;
    const res = await evaluateSubmission({ problemId: 'sum_of_array', code: sumCode, language: 'python' });
    expect(res.success).to.be.true;
    expect(res.status).to.equal('ACCEPTED');
  });

  it('TEST 11: An incorrect DSA solution fails with WRONG_ANSWER', async () => {
    const wrongCode = `import sys
print(99999)
`;
    const res = await evaluateSubmission({ problemId: 'sum_of_array', code: wrongCode, language: 'python' });
    expect(res.success).to.be.false;
    expect(res.status).to.equal('WRONG_ANSWER');
  });

  it('should detect syntax/compilation errors', async () => {
    const syntaxErrorCode = `def solve(
    print("missing paren"
`;
    const res = await evaluateSubmission({ problemId: 'sum_of_array', code: syntaxErrorCode, language: 'python' });
    expect(res.success).to.be.false;
    expect(res.status).to.equal('COMPILATION_ERROR');
  });

  it('should block security-violating system calls', async () => {
    const dangerousCode = `import os
os.system('ls')
`;
    const res = await evaluateSubmission({ problemId: 'sum_of_array', code: dangerousCode, language: 'python' });
    expect(res.success).to.be.false;
    expect(res.status).to.equal('SECURITY_VIOLATION');
  });
});
