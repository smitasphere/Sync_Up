/**
 * Integration and State Machine Tests for Arcade Arena · Tech Verse 2026
 * Covers all required acceptance test cases TEST 1 to TEST 20.
 */

const { expect } = require('chai');
const path = require('path');
const fs = require('fs');

// Use a temporary database for test suite
const testDbPath = path.join(__dirname, '..', 'data', `test_${Date.now()}.db`);
process.env.DB_PATH = testDbPath;

const db = require('../server/database');
db.initDatabase(testDbPath);

const roomManager = require('../server/roomManager');
const gameManager = require('../server/gameManager');
const { getProblemById } = require('../server/dsa/problems');

describe('Full Multiplayer & Authoritative Game Flow Tests (TEST 1 - TEST 20)', function () {
  this.timeout(15000);

  after(() => {
    try {
      if (fs.existsSync(testDbPath)) fs.unlinkSync(testDbPath);
      if (fs.existsSync(testDbPath + '-wal')) fs.unlinkSync(testDbPath + '-wal');
      if (fs.existsSync(testDbPath + '-shm')) fs.unlinkSync(testDbPath + '-shm');
    } catch (e) {}
  });

  it('TEST 1: Two players join the same room successfully', () => {
    const { room, player: p1 } = roomManager.createRoom({ playerName: 'Alice' });
    expect(room.code).to.match(/^TV\d{4}$/);
    expect(p1.playerNum).to.equal(1);

    const joinRes = roomManager.joinRoom(room.code, { playerName: 'Bob' });
    expect(joinRes.success).to.be.true;
    expect(joinRes.player.playerNum).to.equal(2);
    expect(room.players[1]).to.not.be.null;
    expect(room.players[2]).to.not.be.null;
  });

  it('TEST 2: A third player cannot join a full room', () => {
    const { room } = roomManager.createRoom({ playerName: 'Host' });
    roomManager.joinRoom(room.code, { playerName: 'Partner' });

    const thirdJoin = roomManager.joinRoom(room.code, { playerName: 'Intruder' });
    expect(thirdJoin.success).to.be.false;
    expect(thirdJoin.error).to.equal('ROOM_FULL');
  });

  it('TEST 3: Both players submit the same word. The level clears.', () => {
    const { room, player: p1 } = roomManager.createRoom({ playerName: 'Alice' });
    const { player: p2 } = roomManager.joinRoom(room.code, { playerName: 'Bob' });
    gameManager.startGame(room, p1.sessionToken);

    expect(room.currentLevel).to.equal(1);
    gameManager.submitWord(room, p1.sessionToken, 'robot');
    const res = gameManager.submitWord(room, p2.sessionToken, 'robot');

    expect(res.bothSubmitted).to.be.true;
    expect(res.isMatch).to.be.true;
    expect(res.clearedLevel).to.equal(1);
    expect(room.currentLevel).to.equal(2);
    expect(room.currentAttempt).to.equal(1); // Attempts reset for new level
  });

  it('TEST 5: One player submits but the other has not submitted. No answer is revealed.', () => {
    const { room, player: p1 } = roomManager.createRoom({ playerName: 'Alice' });
    const { player: p2 } = roomManager.joinRoom(room.code, { playerName: 'Bob' });
    gameManager.startGame(room, p1.sessionToken);

    const res = gameManager.submitWord(room, p1.sessionToken, 'supersecret');
    expect(res.success).to.be.true;
    expect(res.bothSubmitted).to.be.false;

    const safeState = gameManager.getSafeGameState(room);
    expect(safeState.submissionsLocked[1]).to.be.true;
    expect(safeState.submissionsLocked[2]).to.be.false;
    // Word itself is never exposed in the safe state
    expect(JSON.stringify(safeState)).to.not.include('supersecret');
  });

  it('TEST 7: The team gets three attempts per level', () => {
    const { room, player: p1 } = roomManager.createRoom({ playerName: 'P1' });
    const { player: p2 } = roomManager.joinRoom(room.code, { playerName: 'P2' });
    gameManager.startGame(room, p1.sessionToken);

    // Attempt 1 mismatch
    gameManager.submitWord(room, p1.sessionToken, 'apple');
    let res = gameManager.submitWord(room, p2.sessionToken, 'banana');
    expect(res.isMatch).to.be.false;
    expect(res.remainingAttempts).to.equal(2);
    expect(room.currentAttempt).to.equal(2);

    // Reset phase for attempt 2
    gameManager.proceedToNextAttempt(room);

    // Attempt 2 mismatch
    gameManager.submitWord(room, p1.sessionToken, 'cherry');
    res = gameManager.submitWord(room, p2.sessionToken, 'date');
    expect(res.isMatch).to.be.false;
    expect(res.remainingAttempts).to.equal(1);
    expect(room.currentAttempt).to.equal(3);
  });

  it('TEST 8: The first failed level triggers a DSA challenge', () => {
    const { room, player: p1 } = roomManager.createRoom({ playerName: 'P1' });
    const { player: p2 } = roomManager.joinRoom(room.code, { playerName: 'P2' });
    gameManager.startGame(room, p1.sessionToken);

    // Exhaust all 3 attempts with mismatches
    for (let i = 1; i <= 3; i++) {
      if (i > 1) gameManager.proceedToNextAttempt(room);
      gameManager.submitWord(room, p1.sessionToken, `wordA_${i}`);
      const res = gameManager.submitWord(room, p2.sessionToken, `wordB_${i}`);
      if (i === 3) {
        expect(res.attemptsExhausted).to.be.true;
        expect(res.failedLevels).to.equal(1);
        expect(res.isEliminated).to.be.false;
        expect(room.phase).to.equal('DSA_CHALLENGE');
        expect(room.assignedDsaProblemId).to.be.a('string');
      }
    }
  });

  it('TEST 9 & TEST 12: Second failed level recovered by solving DSA challenge', async () => {
    const { room, player: p1 } = roomManager.createRoom({ playerName: 'P1' });
    const { player: p2 } = roomManager.joinRoom(room.code, { playerName: 'P2' });
    gameManager.startGame(room, p1.sessionToken);

    // Fail Level 1
    for (let i = 1; i <= 3; i++) {
      if (i > 1) gameManager.proceedToNextAttempt(room);
      gameManager.submitWord(room, p1.sessionToken, `w1_${i}`);
      gameManager.submitWord(room, p2.sessionToken, `w2_${i}`);
    }
    expect(room.failedLevels).to.equal(1);

    // Solve DSA for Level 1 using its starter code
    const prob1 = getProblemById(room.assignedDsaProblemId);
    let dsaRes = await gameManager.submitDsaSolution(room, p1.sessionToken, prob1.id, prob1.starterCode, 'python');
    expect(dsaRes.success).to.be.true;
    expect(room.currentLevel).to.equal(2);

    gameManager.proceedToNextLevel(room);

    // Fail Level 2 (2nd failed level)
    for (let i = 1; i <= 3; i++) {
      if (i > 1) gameManager.proceedToNextAttempt(room);
      gameManager.submitWord(room, p1.sessionToken, `w1_${i}`);
      gameManager.submitWord(room, p2.sessionToken, `w2_${i}`);
    }
    expect(room.failedLevels).to.equal(2);
    expect(room.phase).to.equal('DSA_CHALLENGE');

    // Solve DSA for Level 2
    const prob2 = getProblemById(room.assignedDsaProblemId);
    dsaRes = await gameManager.submitDsaSolution(room, p2.sessionToken, prob2.id, prob2.starterCode, 'python');
    expect(dsaRes.success).to.be.true;
    expect(room.currentLevel).to.equal(3);
  });

  it('TEST 10: The third failed level causes immediate elimination', () => {
    const { room, player: p1 } = roomManager.createRoom({ playerName: 'P1' });
    const { player: p2 } = roomManager.joinRoom(room.code, { playerName: 'P2' });
    gameManager.startGame(room, p1.sessionToken);

    // Set failed levels to 2 beforehand
    room.failedLevels = 2;

    // Fail 3 attempts on this level
    for (let i = 1; i <= 3; i++) {
      if (i > 1) gameManager.proceedToNextAttempt(room);
      gameManager.submitWord(room, p1.sessionToken, `a_${i}`);
      const res = gameManager.submitWord(room, p2.sessionToken, `b_${i}`);

      if (i === 3) {
        expect(res.isEliminated).to.be.true;
        expect(res.failedLevels).to.equal(3);
        expect(room.status).to.equal('ELIMINATED');
        expect(room.phase).to.equal('ELIMINATED');
      }
    }
  });

  it('TEST 13 & TEST 14: Refresh / Disconnection recovery from SQLite', () => {
    const { room, player: p1 } = roomManager.createRoom({ playerName: 'Alice' });
    const { player: p2 } = roomManager.joinRoom(room.code, { playerName: 'Bob' });
    gameManager.startGame(room, p1.sessionToken);

    // Advance to Level 4
    room.currentLevel = 4;
    room.failedLevels = 1;
    db.updateRoomStateInDb(room.id, { current_level: 4, failed_levels: 1 });

    // Player 1 disconnects/refreshes and reconnects using session token
    const reconnectResult = roomManager.reconnectPlayer(room.code, p1.sessionToken);
    expect(reconnectResult.success).to.be.true;
    expect(reconnectResult.player.playerNum).to.equal(1);
    expect(reconnectResult.room.currentLevel).to.equal(4);
    expect(reconnectResult.room.failedLevels).to.equal(1);
  });

  it('TEST 15 & TEST 16: Level 9 completion produces victory; never advances beyond Level 9', () => {
    const { room, player: p1 } = roomManager.createRoom({ playerName: 'Alice' });
    const { player: p2 } = roomManager.joinRoom(room.code, { playerName: 'Bob' });
    gameManager.startGame(room, p1.sessionToken);

    // Fast-forward to Level 9
    room.currentLevel = 9;
    db.updateRoomStateInDb(room.id, { current_level: 9 });

    gameManager.submitWord(room, p1.sessionToken, 'quantum');
    const res = gameManager.submitWord(room, p2.sessionToken, 'quantum');

    expect(res.bothSubmitted).to.be.true;
    expect(res.isMatch).to.be.true;
    expect(res.isGameWon).to.be.true;
    expect(res.clearedLevel).to.equal(9);
    expect(room.currentLevel).to.equal(9); // Must NOT advance to Level 10
    expect(room.status).to.equal('WON');
    expect(room.phase).to.equal('GAME_COMPLETED');
  });

  it('TEST 17: Duplicate submissions cannot advance the game twice', () => {
    const { room, player: p1 } = roomManager.createRoom({ playerName: 'Alice' });
    const { player: p2 } = roomManager.joinRoom(room.code, { playerName: 'Bob' });
    gameManager.startGame(room, p1.sessionToken);

    gameManager.submitWord(room, p1.sessionToken, 'first');
    const dupRes = gameManager.submitWord(room, p1.sessionToken, 'second');
    expect(dupRes.success).to.be.false;
    expect(dupRes.error).to.equal('ALREADY_SUBMITTED');
  });

  it('TEST 18: Two rooms operate independently without sharing state', () => {
    const { room: r1, player: r1p1 } = roomManager.createRoom({ playerName: 'R1P1' });
    const { room: r2, player: r2p1 } = roomManager.createRoom({ playerName: 'R2P1' });

    const { player: r1p2 } = roomManager.joinRoom(r1.code, { playerName: 'R1P2' });
    const { player: r2p2 } = roomManager.joinRoom(r2.code, { playerName: 'R2P2' });

    gameManager.startGame(r1, r1p1.sessionToken);
    gameManager.startGame(r2, r2p1.sessionToken);

    // Advance room 1 to Level 2
    gameManager.submitWord(r1, r1p1.sessionToken, 'match');
    gameManager.submitWord(r1, r1p2.sessionToken, 'match');

    expect(r1.currentLevel).to.equal(2);
    expect(r2.currentLevel).to.equal(1); // Room 2 remains on Level 1
  });

  it('TEST 19: Players cannot skip levels by modifying client-side data', () => {
    const { room, player: p1 } = roomManager.createRoom({ playerName: 'Alice' });
    const { player: p2 } = roomManager.joinRoom(room.code, { playerName: 'Bob' });
    gameManager.startGame(room, p1.sessionToken);

    // Attempting to proceed to next level when level was not cleared
    const invalidNext = gameManager.proceedToNextLevel(room);
    expect(invalidNext.success).to.be.false;
    expect(invalidNext.error).to.equal('INVALID_PHASE');
    expect(room.currentLevel).to.equal(1);
  });

  it('TEST 20: The game cannot progress after elimination', () => {
    const { room, player: p1 } = roomManager.createRoom({ playerName: 'Alice' });
    const { player: p2 } = roomManager.joinRoom(room.code, { playerName: 'Bob' });
    gameManager.startGame(room, p1.sessionToken);

    // Eliminate room
    room.status = 'ELIMINATED';
    room.phase = 'ELIMINATED';
    room.failedLevels = 3;

    const submitRes = gameManager.submitWord(room, p1.sessionToken, 'test');
    expect(submitRes.success).to.be.false;
    expect(submitRes.error).to.equal('GAME_NOT_ACTIVE');
  });
});
