/**
 * End-to-End Simulation Script
 * Simulates two live players connecting, creating a room, matching words,
 * handling mismatches, and verifying real-time synchronization.
 */

const io = require('socket.io-client');

async function runSimulation() {
  const SERVER_URL = 'http://localhost:3000';
  console.log('--- Starting Two-Player Live Simulation ---');

  const p1 = io(SERVER_URL, { reconnection: false });
  const p2 = io(SERVER_URL, { reconnection: false });

  await new Promise((resolve) => p1.on('connect', resolve));
  console.log('✔ Player 1 socket connected');

  await new Promise((resolve) => p2.on('connect', resolve));
  console.log('✔ Player 2 socket connected');

  // Step 1: Player 1 creates room
  const roomData = await new Promise((resolve) => {
    p1.emit('create_room', { playerName: 'Player 1' }, resolve);
  });
  console.log(`✔ Room created: ${roomData.roomCode} (Session: ${roomData.sessionToken.slice(0, 8)}...)`);

  // Step 2: Player 2 joins room
  const joinData = await new Promise((resolve) => {
    p2.emit('join_room', { roomId: roomData.roomCode, playerName: 'Player 2' }, resolve);
  });
  console.log(`✔ Player 2 joined room ${joinData.roomCode}!`);

  // Step 3: Player 1 starts game
  const startPromise = Promise.all([
    new Promise((resolve) => p1.once('game_started', resolve)),
    new Promise((resolve) => p2.once('game_started', resolve))
  ]);
  p1.emit('start_game', { roomId: roomData.roomCode, sessionToken: roomData.sessionToken });
  const [start1, start2] = await startPromise;
  console.log(`✔ Game started! Current Level: ${start1.gameState.currentLevel} (${start1.gameState.zone.name})`);

  // Step 4: Level 1 Word Guess (Secret submission)
  const lockedPromise = new Promise((resolve) => p2.once('answer_locked', resolve));
  p1.emit('submit_word', {
    roomId: roomData.roomCode,
    sessionToken: roomData.sessionToken,
    word: 'Robot'
  });
  const lockedEvt = await lockedPromise;
  console.log(`✔ Player 1 submitted in secret. Player 2 notified: "${lockedEvt.message}"`);

  // Player 2 submits matching word
  const matchPromise = Promise.all([
    new Promise((resolve) => p1.once('attempt_result', resolve)),
    new Promise((resolve) => p2.once('attempt_result', resolve))
  ]);
  p2.emit('submit_word', {
    roomId: roomData.roomCode,
    sessionToken: joinData.sessionToken,
    word: 'robot'
  });
  const [matchResult] = await matchPromise;
  console.log(`✔ Both submitted! Match result: ${matchResult.isMatch ? 'MATCH!' : 'NO MATCH'}`);
  console.log(`  Revealed: P1="${matchResult.p1Word}" vs P2="${matchResult.p2Word}"`);

  // Step 5: Advance to Level 2
  const level2Promise = Promise.all([
    new Promise((resolve) => p1.once('level_started', resolve)),
    new Promise((resolve) => p2.once('level_started', resolve))
  ]);
  p1.emit('request_next_level', { roomId: roomData.roomCode });
  const [lvl2State] = await level2Promise;
  console.log(`✔ Both advanced to Level ${lvl2State.gameState.currentLevel}: ${lvl2State.gameState.zone.name}!`);

  p1.disconnect();
  p2.disconnect();
  console.log('--- Simulation Completed Successfully! ---');
}

runSimulation().catch((err) => {
  console.error('Simulation error:', err);
  process.exit(1);
});
