/**
 * Two Browser Sessions Flow Test
 * Verifies Room Creation, Room Code display, Invite Link with LAN IP, QR Code URL,
 * Player 2 Join via URL hash/code, and Game Start Synchronization.
 */

const { expect } = require('chai');
const io = require('socket.io-client');

describe('Two Browser Sessions Multiplayer Flow Verification', function () {
  this.timeout(10000);

  const SERVER_URL = 'http://localhost:3000';
  let session1Socket;
  let session2Socket;
  let createdRoomCode;
  let createdJoinUrl;
  let createdP1Token;
  let createdP2Token;

  after(() => {
    if (session1Socket && session1Socket.connected) session1Socket.disconnect();
    if (session2Socket && session2Socket.connected) session2Socket.disconnect();
  });

  it('Requirement 1 & 3: Session 1 creates room and receives unique room code, joinUrl with LAN IP, and gameState', (done) => {
    session1Socket = io(SERVER_URL, { reconnection: false });

    session1Socket.on('connect', () => {
      session1Socket.emit('create_room', { playerName: 'Player 1' }, (response) => {
        expect(response).to.be.an('object');
        expect(response.success).to.be.true;
        expect(response.roomCode).to.match(/^TV\d{4}$/);
        expect(response.playerNum).to.equal(1);
        expect(response.joinUrl).to.be.a('string').and.include(response.roomCode);
        expect(response.sessionToken).to.be.a('string');
        // Verify LAN IP address is included in the joinUrl
        expect(response.joinUrl).to.match(/http:\/\/\d+\.\d+\.\d+\.\d+:3000\/#TV\d{4}/);

        createdRoomCode = response.roomCode;
        createdJoinUrl = response.joinUrl;
        createdP1Token = response.sessionToken;

        expect(response.gameState).to.be.an('object');
        expect(response.gameState.roomCode).to.equal(createdRoomCode);
        expect(response.gameState.status).to.equal('LOBBY');
        expect(response.gameState.players[1].connected).to.be.true;
        expect(response.gameState.players[2]).to.be.null;

        done();
      });
    });
  });

  it('Requirement 4 & 5: Session 2 joins the same room using the room code and both devices synchronize', (done) => {
    session2Socket = io(SERVER_URL, { reconnection: false });

    // Expect session 1 to receive notification that Player 2 joined and game is ready
    let session1Notified = false;
    session1Socket.on('player_joined', (data) => {
      expect(data.playerNum).to.equal(2);
      session1Notified = true;
    });

    session1Socket.on('game_ready', (data) => {
      expect(session1Notified).to.be.true;
      expect(data.gameState.players[1].connected).to.be.true;
      expect(data.gameState.players[2].connected).to.be.true;
    });

    session2Socket.on('connect', () => {
      session2Socket.emit('join_room', { roomId: createdRoomCode, playerName: 'Player 2' }, (response) => {
        expect(response).to.be.an('object');
        expect(response.success).to.be.true;
        expect(response.roomCode).to.equal(createdRoomCode);
        expect(response.playerNum).to.equal(2);
        expect(response.isHost).to.be.false;
        expect(response.sessionToken).to.be.a('string');
        createdP2Token = response.sessionToken;

        expect(response.gameState.players[1].connected).to.be.true;
        expect(response.gameState.players[2].connected).to.be.true;

        done();
      });
    });
  });

  it('Requirement 7: Third session trying to join full room receives meaningful error', (done) => {
    const session3 = io(SERVER_URL, { reconnection: false });
    session3.on('connect', () => {
      session3.emit('join_room', { roomId: createdRoomCode, playerName: 'Player 3' }, (response) => {
        expect(response.success).to.be.false;
        expect(response.error).to.equal('ROOM_FULL');
        expect(response.message).to.be.a('string').and.include('2 players');
        session3.disconnect();
        done();
      });
    });
  });

  it('Requirement 8: Host starts game, both players synchronize, submit words, and match', (done) => {
    let s1Started = false;
    let s2Started = false;

    session1Socket.once('game_started', (data) => {
      s1Started = true;
      expect(data.gameState.currentLevel).to.equal(1);
      expect(data.gameState.phase).to.equal('GUESSING');
    });

    session2Socket.once('game_started', (data) => {
      s2Started = true;
      expect(data.gameState.currentLevel).to.equal(1);

      // Now Player 1 submits secret word
      session1Socket.emit('submit_word', {
        roomId: createdRoomCode,
        sessionToken: createdP1Token,
        word: 'Robot'
      });
    });

    // Player 2 receives notification that Player 1 locked in (without revealing word)
    session2Socket.once('answer_locked', (data) => {
      expect(data.playerNum).to.equal(1);
      expect(data.gameState.submissionsLocked[1]).to.be.true;
      expect(data.gameState.submissionsLocked[2]).to.be.false;

      // Player 2 submits matching word
      session2Socket.emit('submit_word', {
        roomId: createdRoomCode,
        sessionToken: createdP2Token,
        word: 'robot'
      });
    });

    // Both players receive attempt_result and level_cleared
    session1Socket.once('level_cleared', (data) => {
      expect(s1Started && s2Started).to.be.true;
      expect(data.clearedLevel).to.equal(1);
      expect(data.nextLevel).to.equal(2);
      done();
    });

    // Start game from Session 1 (Host)
    session1Socket.emit('start_game', {
      roomId: createdRoomCode,
      sessionToken: createdP1Token
    });
  });
});
