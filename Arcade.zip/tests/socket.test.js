/**
 * Socket.IO Real-time Connection Integration Tests
 */

const { expect } = require('chai');
const http = require('http');
const ioClient = require('socket.io-client');
const { app, getBaseUrl } = require('../server/app');
const { setupSocketIO } = require('../server/socket');

describe('Socket.IO Real-time Multiplayer Integration', function () {
  this.timeout(10000);

  let server;
  let serverPort;
  let client1;
  let client2;
  let client3;

  before((done) => {
    server = http.createServer(app);
    setupSocketIO(server, getBaseUrl);
    server.listen(0, () => {
      serverPort = server.address().port;
      done();
    });
  });

  after((done) => {
    if (client1 && client1.connected) client1.disconnect();
    if (client2 && client2.connected) client2.disconnect();
    if (client3 && client3.connected) client3.disconnect();
    server.close(done);
  });

  it('connects two socket clients and synchronizes room joining', (done) => {
    const url = `http://localhost:${serverPort}`;
    client1 = ioClient(url, { reconnection: false });

    client1.on('connect', () => {
      client1.emit('create_room', { playerName: 'HostPlayer' }, (res) => {
        expect(res.success).to.be.true;
        expect(res.roomCode).to.match(/^TV\d{4}$/);
        const code = res.roomCode;

        client2 = ioClient(url, { reconnection: false });
        client2.on('connect', () => {
          client2.emit('join_room', { roomId: code, playerName: 'GuestPlayer' }, (joinRes) => {
            expect(joinRes.success).to.be.true;
            expect(joinRes.playerNum).to.equal(2);

            // Third socket trying to join must be rejected with room_full
            client3 = ioClient(url, { reconnection: false });
            client3.on('connect', () => {
              client3.emit('join_room', { roomId: code, playerName: 'ExtraPlayer' }, (extraRes) => {
                expect(extraRes.success).to.be.false;
                expect(extraRes.error).to.equal('ROOM_FULL');
                done();
              });
            });
          });
        });
      });
    });
  });
});
