/**
 * Unit Tests for Game Rules, Word Normalization, and Zones
 */

const { expect } = require('chai');
const {
  normalizeWord,
  wordsMatch,
  validateWordSubmission,
  getZoneForLevel,
  MAX_LEVELS,
  MAX_ATTEMPTS_PER_LEVEL,
  MAX_FAILED_LEVELS
} = require('../server/gameRules');

describe('Game Rules & Normalization', () => {
  it('should have 9 distinct levels defined', () => {
    expect(MAX_LEVELS).to.equal(9);
    for (let i = 1; i <= 9; i++) {
      const zone = getZoneForLevel(i);
      expect(zone).to.not.be.null;
      expect(zone.level).to.equal(i);
      expect(zone.name).to.be.a('string');
      expect(zone.question).to.be.a('string');
    }
  });

  it('TEST 4: Answers differing only in capitalization match', () => {
    expect(wordsMatch('Robot', 'robot')).to.be.true;
    expect(wordsMatch('ROBOT', 'robot')).to.be.true;
    expect(wordsMatch('rObOt', 'RoBoT')).to.be.true;
  });

  it('should match words with leading and trailing whitespace', () => {
    expect(wordsMatch('  robot  ', 'robot')).to.be.true;
    expect(wordsMatch(' neural  network ', 'neural network')).to.be.true;
  });

  it('TEST 6: Two different words produce a mismatch', () => {
    expect(wordsMatch('robot', 'computer')).to.be.false;
    expect(wordsMatch('laptop', 'desktop')).to.be.false;
  });

  it('should reject empty or whitespace-only submissions', () => {
    expect(validateWordSubmission('').valid).to.be.false;
    expect(validateWordSubmission('   ').valid).to.be.false;
    expect(validateWordSubmission(null).valid).to.be.false;
  });

  it('should enforce maximum word length', () => {
    const longWord = 'a'.repeat(33);
    const result = validateWordSubmission(longWord);
    expect(result.valid).to.be.false;
  });

  it('should define 3 attempts per level and 3 failed levels for elimination', () => {
    expect(MAX_ATTEMPTS_PER_LEVEL).to.equal(3);
    expect(MAX_FAILED_LEVELS).to.equal(3);
  });
});
